<?php
// db_connection.php - Make sure this file contains your database connection details.
include("db_connection.php");

// Fetch the total number of users from the users table
$sql_user_count = "SELECT COUNT(*) AS total_users FROM users";
$result = $conn->query($sql_user_count);

// Fetch the number of users with completed profiles
$sql_completed_profiles = "SELECT COUNT(*) AS completed_profiles 
                           FROM users 
                           WHERE profile_picture != '' 
                             AND full_name != '' 
                             AND address != '' 
                             AND department != '' 
                             AND faculty != '' 
                             AND level != '' 
                             AND about_me != '' 
                             AND interests != '' 
                             AND gender != ''";
$result_completed_profiles = $conn->query($sql_completed_profiles);

// Check if the query was successful
if ($result && $result_completed_profiles) {
    // Fetch the results
    $user_count = $result->fetch_assoc()['total_users'];
    $completed_profiles = $result_completed_profiles->fetch_assoc()['completed_profiles'];

    // Calculate the number of incomplete profiles
    $incomplete_profiles = $user_count - $completed_profiles;
} else {
    $completed_profiles = 0;
    $incomplete_profiles = 0;
}

// Close the database connection
$conn->close();
?>






<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link href='https://unpkg.com/boxicons@2.0.9/css/boxicons.min.css' rel='stylesheet'>
	<link rel="stylesheet" href="style.css">
	<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
	<title>Unimaid connect chief admin</title>
	<style>
		 body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 20px;
            background-color: #f9f9f9;
        }
        .chart-container {
            width: 100%;
            margin: 0 auto;
            padding: 20px;
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }
        h2 {
            text-align: center;
            color: #6a1b9a;
        }
	</style>
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">

</head>
<body>
	
	<!-- SIDEBAR -->
	<section id="sidebar">
		<a href="#" class="brand"><i class='bx bxs-smile icon'></i>Chief Admin</a>
		<ul class="side-menu">
			<li><a href="#" class="active"><i class='bx bxs-dashboard icon' ></i> Dashboard</a></li>
			<li class="divider" data-text="main">Main</li>
			<li>
				<a href="#"><i class='bx bxs-inbox icon' ></i> Approvals <i class='bx bx-chevron-right icon-right' ></i></a>
				<ul class="side-dropdown">
					<li><a href="approve_mkt.php">Approve Mkt post</a></li>
					<li><a href="manage_events.php">Manage Events</a></li>
					<li><a href="post_ads.php">Posts Ads</a></li>
					<li><a href="group_settings.php">Groups settings</a></li>
				</ul>
			</li>
			<li><a href="loan_requests.php"><i class='bx bxs-chart icon' ></i> Loans</a></li>
			<li><a href="users.php"><i class='bx bxs-widget icon' ></i> users</a></li>
			<li class="divider" data-text="table and forms">More </li>
			<li><a href="verify_user.php"><i class='bx bx-table icon' ></i> Verify Users</a></li>
			<li>
				<a href="#"><i class='bx bxs-notepad icon' ></i> More <i class='bx bx-chevron-right icon-right' ></i></a>
				<ul class="side-dropdown">
					<li><a href="admin_approve.php">Approve WCW</a></li>
					<li><a href="#">Pink verification</a></li>
					<li><a href="#">Black verification</a></li>
					
					<li><a href="usermessages.php">send user messages</a></li>
				</ul>
			</li>
		</ul>
		<div class="ads">
		
		</div>
	</section>
	<!-- SIDEBAR -->

	<!-- NAVBAR -->
	<section id="content">
		<!-- NAVBAR -->
		<nav>
			<i class='bx bx-menu toggle-sidebar' ></i>
			<form action="#">
				<div class="form-group">
					<input type="text" placeholder="Search...">
					<i class='bx bx-search icon' ></i>
				</div>
			</form>
			<a href="#" class="nav-link">
				<i class='bx bxs-bell icon' ></i>
				<span class="badge">5</span>
			</a>
			<a href="usermessages.php" class="nav-link">
			<i class="fa fa-spinner fa-spin" style="color: red;"></i>
			</a>
			<span class="divider"></span>
			<div class="profile">
				<img src="images/singlelogo.png" alt="">
				<ul class="profile-link">
					<li><a href="#"><i class='bx bxs-user-circle icon' ></i> Profile</a></li>
					<li><a href="#"><i class='bx bxs-cog' ></i> Settings</a></li>
					<li><a href="logout.php"><i class='bx bxs-log-out-circle' ></i> Logout</a></li>
				</ul>
			</div>
		</nav>
		<!-- NAVBAR -->

		<!-- MAIN -->
		<main>
			<h1 class="title">Dashboard</h1>
			<ul class="breadcrumbs">
				<li><a href="#">Home</a></li>
				<li class="divider">/</li>
				<li><a href="#" class="active">Dashboard</a></li>
			</ul>
			<div class="info-data">
				<div class="card">
					<div class="head">
						<div>
							<h2><?php echo "$user_count" ?></h2>
							<p>Students</p>
						</div>
						<i class='bx bx-trending-up icon' ></i>
					</div>
					<span class="progress" data-value="40%"></span>
					<span class="label">Total Number of students</span>
				</div>
				<div class="card">
					<div class="head">
						<div>
							<h2><?php echo $completed_profiles; ?></h2>
							<p>completed profile</p>
						</div>
						<i class='bx bx-trending-down icon down' ></i>
					</div>
					<span class="progress" data-value="60%"></span>
					<span class="label">All profile fields completed</span>
				</div>
				<div class="card">
					<div class="head">
						<div>
							<h2><?php echo $incomplete_profiles; ?></h2>
						<i class='bx bx-trending-up icon' ></i>
					</div>
					<span class="progress" data-value="30%"></span>
					<span class="label">30%</span>
				</div>
				<div class="card">
					<div class="head">
						<div>
							<h2>235</h2>
							<p>Visitors</p>
						</div>
						<i class='bx bx-trending-up icon' ></i>
					</div>
					<span class="progress" data-value="80%"></span>
					<span class="label">80%</span>
				</div>
			</div>
			<div class="data">
				<div class="content-data">
					<div class="head">
						<h3> Profile Completion rate</h3>
						<div class="menu">
							<i class='bx bx-dots-horizontal-rounded icon'></i>
							<ul class="menu-link">
								<li><a href="#">Edit</a></li>
								<li><a href="#">Save</a></li>
								<li><a href="#">Remove</a></li>
							</ul>
						</div>
					</div>
					<div class="chart">
						<div id="">

						<div class="chart-container">
    
    <canvas id="profileChart"></canvas>
</div>

						</div>
					</div>
				</div>
				<div class="content-data">
					<div class="head">
						<h3>Chatbox</h3>
						<div class="menu">
							<i class='bx bx-dots-horizontal-rounded icon'></i>
							<ul class="menu-link">
								<li><a href="#">Edit</a></li>
								<li><a href="#">Save</a></li>
								<li><a href="#">Remove</a></li>
							</ul>
						</div>
					</div>
					<div class="chat-box">
						<p class="day"><span>Today</span></p>
						
						<?php
// Database connection settings
include('db_connection.php');
// You can specify which page(s) you want to show statistics for
// For example, to show views for `page1.php`:
$page = 'page1.php';  // Set this to the page you want to show statistics for

// Fetch the view count for that page
$sql = "SELECT views FROM page_views WHERE page = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $page);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    // Fetch the view count
    $row = $result->fetch_assoc();
    echo "Page '$page' has been viewed " . $row['views'] . " times.";
} else {
    echo "No views recorded for this page.";
}

// Close prepared statement and connection
$stmt->close();
$conn->close();
?>

				</div>
			</div>
		</main>
		<!-- MAIN -->
	</section>
	<!-- NAVBAR -->
	 
<script>
// Data for the chart
const ctx = document.getElementById('profileChart').getContext('2d');
const profileChart = new Chart(ctx, {
    type: 'pie', // You can change this to 'bar', 'line', etc.
    data: {
        labels: ['Completed Profiles', 'Incomplete Profiles'],
        datasets: [{
            label: 'Profile Completion',
            data: [<?php echo $completed_profiles; ?>, <?php echo $incomplete_profiles; ?>],
            backgroundColor: ['#4caf50', '#ff5722'],
            hoverOffset: 4
        }]
    },
    options: {
        responsive: true,
        plugins: {
            legend: {
                position: 'top',
            },
            tooltip: {
                callbacks: {
                    label: function(tooltipItem) {
                        return tooltipItem.label + ': ' + tooltipItem.raw + ' users';
                    }
                }
            }
        }
    }
});
</script>


	<script src="https://cdn.jsdelivr.net/npm/apexcharts"></script>
	<script src="script.js"></script>
</body>
</html>