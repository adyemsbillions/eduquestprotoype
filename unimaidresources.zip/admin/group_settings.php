<?php
session_start();

// Ensure the user is logged in
if (!isset($_SESSION['user_id'])) {
    die("You need to log in first.");
}

// Database connection
$conn = new mysqli('localhost', 'root', '', 'unimaidconnect');

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Handle post request to update can_post status
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Make sure group ID is set
    if (isset($_POST['group_id'])) {
        $groupId = $_POST['group_id'];
        $canPost = isset($_POST['can_post']) ? 1 : 0;

        // Update the 'can_post' value in the database
        $sqlUpdatePostStatus = "UPDATE groups SET can_post = '$canPost' WHERE id = '$groupId'";

        if ($conn->query($sqlUpdatePostStatus) === TRUE) {
            echo "Group post settings updated successfully!";
            header("Location: group_settings.php"); // Refresh to see the updated settings
            exit();
        } else {
            echo "Error: " . $conn->error;
        }
    }
}

// Fetch all groups
$sql = "SELECT id, name, can_post FROM groups";
$groupsResult = $conn->query($sql);

// Check if any groups are available
if ($groupsResult->num_rows == 0) {
    echo "No groups found.";
    exit();
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Groups</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f4;
        }
        .container {
            width: 80%;
            margin: 0 auto;
            padding: 20px;
            background-color: #fff;
        }
        h1 {
            font-size: 24px;
            color: #333;
        }
        .group-list {
            margin-top: 20px;
        }
        .group-item {
            margin-bottom: 20px;
            padding: 15px;
            background-color: #f9f9f9;
            border: 1px solid #ccc;
            border-radius: 5px;
        }
        .group-item h3 {
            margin: 0;
            font-size: 20px;
        }
        .group-item form {
            margin-top: 10px;
        }
        .group-item input[type="submit"] {
            background-color: purple;
            color: white;
            padding: 8px 16px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }
        .group-item input[type="submit"]:hover {
            background-color: #45a049;
        }
        .group-item input[type="checkbox"] {
            margin-right: 10px;
        }
    </style>
</head>
<body>

    <div class="container">
        <h1>Manage All Groups</h1>

        <div class="group-list">
            <?php while ($group = $groupsResult->fetch_assoc()) { ?>
                <div class="group-item">
                    <h3><?php echo htmlspecialchars($group['name']); ?></h3>
                    <form action="group_settings.php" method="POST">
                        <input type="hidden" name="group_id" value="<?php echo $group['id']; ?>">
                        <label for="can_post">Allow Members to Post:</label>
                        <input type="checkbox" name="can_post" <?php echo ($group['can_post'] == 1) ? 'checked' : ''; ?>>
                        <input type="submit" value="Save Settings">
                    </form>
                    <p><strong>Number of Members:</strong> <?php echo getGroupMemberCount($group['id'], $conn); ?></p>
                </div>
            <?php } ?>
        </div>
    </div>

</body>
</html>

<?php
// Close the database connection
$conn->close();

// Function to get the number of members in a group
function getGroupMemberCount($groupId, $conn) {
    $sqlMembers = "SELECT COUNT(*) AS member_count FROM group_members WHERE group_id = '$groupId'";
    $result = $conn->query($sqlMembers);
    $row = $result->fetch_assoc();
    return $row['member_count'];
}
?>
