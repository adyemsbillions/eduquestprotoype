<?php
// db.php: Database connection file
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "unimaidconnect";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// send_message.php: Process the form and store the message


if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $message = $_POST['message'];
    $user = $_POST['user']; // The user to send the message to
    
    // Get the sender's user ID (assuming session is already started and the sender is logged in)
    session_start();
    $sender_id = $_SESSION['user_id']; // Assuming user_id is stored in session

    // If sending to all users
    if ($user === 'all') {
        // Get all users except the sender
        $query = "SELECT id FROM users WHERE id != ?";
        $stmt = $conn->prepare($query);
        $stmt->bind_param("i", $sender_id);
        $stmt->execute();
        $result = $stmt->get_result();

        while ($row = $result->fetch_assoc()) {
            $receiver_id = $row['id'];
            $insert_query = "INSERT INTO usermessages (sender_id, receiver_id, message) VALUES (?, ?, ?)";
            $stmt = $conn->prepare($insert_query);
            $stmt->bind_param("iis", $sender_id, $receiver_id, $message);
            $stmt->execute();
        }

        echo "Message sent to all users.";
    } else {
        // If sending to a specific user
        $insert_query = "INSERT INTO usermessages (sender_id, receiver_id, message) VALUES (?, ?, ?)";
        $stmt = $conn->prepare($insert_query);
        $stmt->bind_param("iis", $sender_id, $user, $message);
        $stmt->execute();

        echo "Message sent to selected user.";
    }
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Compose Message</title>
    <link rel="stylesheet" href="styles.css">
    <style>
        body {
    font-family: Arial, sans-serif;
    background-color: #f4f4f4;
    margin: 0;
    padding: 0;
}

.container {
    width: 50%;
    margin: 50px auto;
    padding: 20px;
    background-color: #fff;
    border-radius: 8px;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
}

h1 {
    text-align: center;
    color: #333;
}

form {
    display: flex;
    flex-direction: column;
}

label {
    font-size: 16px;
    margin: 10px 0 5px;
}

textarea {
    padding: 10px;
    font-size: 14px;
    border-radius: 5px;
    border: 1px solid #ddd;
    margin-bottom: 15px;
    resize: vertical;
}

select {
    padding: 10px;
    font-size: 14px;
    border-radius: 5px;
    border: 1px solid #ddd;
    margin-bottom: 20px;
}

button {
    padding: 10px 20px;
    background-color: #007bff;
    color: white;
    border: none;
    border-radius: 5px;
    cursor: pointer;
    font-size: 16px;
}

button:hover {
    background-color: #0056b3;
}

    </style>
</head>
<body>
    <div class="container">
        <h1>Send Message</h1>
        <form action="usermessages.php" method="POST">
            <label for="message">Message:</label>
            <textarea id="message" name="message" required></textarea>
            
            <label for="user">Send to:</label>
            <select id="user" name="user">
                <option value="all">All Users</option>
                <?php
                    // PHP code to get the list of users from the database
                    include 'db.php'; // Include the database connection file

                    $query = "SELECT id, username FROM users"; // Assuming a 'users' table
                    $result = $conn->query($query);

                    while ($row = $result->fetch_assoc()) {
                        echo "<option value='{$row['id']}'>{$row['username']}</option>";
                    }
                ?>
            </select>

            <button type="submit">Send Message</button>
        </form>
    </div>
</body>
</html>
