<?php
// Assuming you've included your database connection file
require_once 'db_connection.php';

// Handle user verification/unverification
if (isset($_POST['user_id']) && isset($_POST['action'])) {
    $user_id = $_POST['user_id'];
    $action = $_POST['action'];

    if ($action == 'blue_verify') {
        // Update the user to blue verified (1)
        $sql = "UPDATE users SET verified = 1 WHERE id = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("i", $user_id);
        if ($stmt->execute()) {
            echo json_encode(["status" => "success", "message" => "User successfully blue verified."]);
        } else {
            echo json_encode(["status" => "error", "message" => "Error blue verifying user."]);
        }
    } elseif ($action == 'gold_verify') {
        // Update the user to gold verified (2)
        $sql = "UPDATE users SET verified = 2 WHERE id = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("i", $user_id);
        if ($stmt->execute()) {
            echo json_encode(["status" => "success", "message" => "User successfully gold verified."]);
        } else {
            echo json_encode(["status" => "error", "message" => "Error gold verifying user."]);
        }
    } elseif ($action == 'black_verify') {
        // Update the user to black verified (3)
        $sql = "UPDATE users SET verified = 3 WHERE id = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("i", $user_id);
        if ($stmt->execute()) {
            echo json_encode(["status" => "success", "message" => "User successfully black verified."]);
        } else {
            echo json_encode(["status" => "error", "message" => "Error black verifying user."]);
        }
    } elseif ($action == 'pink_verify') {
        // Update the user to pink verified (4)
        $sql = "UPDATE users SET verified = 4 WHERE id = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("i", $user_id);
        if ($stmt->execute()) {
            echo json_encode(["status" => "success", "message" => "User successfully pink verified."]);
        } else {
            echo json_encode(["status" => "error", "message" => "Error pink verifying user."]);
        }
    } elseif ($action == 'unverify') {
        // Update the user to unverified (0)
        $sql = "UPDATE users SET verified = 0 WHERE id = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("i", $user_id);
        if ($stmt->execute()) {
            echo json_encode(["status" => "success", "message" => "User successfully unverified."]);
        } else {
            echo json_encode(["status" => "error", "message" => "Error un-verifying user."]);
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Verify Users</title>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&display=swap" rel="stylesheet">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <style>
        body {
            font-family: 'Roboto', sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f7fc;
            color: #333;
        }

        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 20px;
        }

        h2 {
            text-align: center;
            margin-bottom: 30px;
            color: #4CAF50;
        }

        .user-list {
            display: flex;
            flex-wrap: wrap;
            justify-content: space-between;
        }

        .user-card {
            width: calc(33.33% - 20px);
            margin: 10px;
            background: #fff;
            padding: 15px;
            border-radius: 8px;
            border: 1px solid #ddd;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            text-align: center;
        }

        .user-card img {
            width: 60px;
            height: 60px;
            border-radius: 50%;
            margin-bottom: 10px;
        }

        .user-card button {
            padding: 10px 20px;
            margin-top: 10px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 14px;
            font-weight: 500;
            transition: background-color 0.3s ease;
        }

        .blue-verify-btn { background-color: #2196F3; color: white; }
        .gold-verify-btn { background-color: gold; color: white; }
        .black-verify-btn { background-color: black; color: white; }
        .pink-verify-btn { background-color: pink; color: black; }
        .unverify-btn { background-color: #f44336; color: white; }

        .blue-verify-btn:hover { background-color: #0b79d2; }
        .gold-verify-btn:hover { background-color: #ffd700; }
        .black-verify-btn:hover { background-color: #333; }
        .pink-verify-btn:hover { background-color: #ff66b2; }
        .unverify-btn:hover { background-color: #e53935; }

        .alert {
            display: none;
            padding: 15px;
            margin-top: 20px;
            font-size: 16px;
            text-align: center;
            border-radius: 5px;
            transition: opacity 0.5s ease;
        }

        .alert.success { background-color: #4CAF50; color: white; }
        .alert.error { background-color: #f44336; color: white; }

        @media (max-width: 768px) { .user-card { width: calc(50% - 20px); } }
        @media (max-width: 480px) { .user-card { width: 100%; } }
    </style>
</head>
<body>

<div class="container">
    <h2>All Users</h2>

    <!-- Alert Box -->
    <div id="alert-box" class="alert"></div>

    <div class="user-list">
        <?php
        // Fetch all users from the database
        $sql = "SELECT id, username, profile_picture, verified FROM users";
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            while ($user = $result->fetch_assoc()) {
                echo '<div class="user-card">';
                echo '<img class="avatar-img" src="/unimaidconnect/dashboard/' . htmlspecialchars($user['profile_picture']) . '" alt="avatar">'; 
                echo '<p>' . htmlspecialchars($user['username']) . '</p>';

                if ($user['verified'] == 0) {
                    echo '<button class="blue-verify-btn" data-user-id="' . $user['id'] . '">Blue Verify</button>';
                    echo '<button class="gold-verify-btn" data-user-id="' . $user['id'] . '">Gold Verify</button>';
                    echo '<button class="black-verify-btn" data-user-id="' . $user['id'] . '">Black Verify</button>';
                    echo '<button class="pink-verify-btn" data-user-id="' . $user['id'] . '">Pink Verify</button>';
                } elseif ($user['verified'] == 1) {
                    echo '<button class="unverify-btn" data-user-id="' . $user['id'] . '">Unverify</button>';
                    echo '<button class="gold-verify-btn" data-user-id="' . $user['id'] . '">Gold Verify</button>';
                    echo '<button class="black-verify-btn" data-user-id="' . $user['id'] . '">Black Verify</button>';
                    echo '<button class="pink-verify-btn" data-user-id="' . $user['id'] . '">Pink Verify</button>';
                } elseif ($user['verified'] == 2) {
                    echo '<button class="unverify-btn" data-user-id="' . $user['id'] . '">Unverify</button>';
                    echo '<button class="blue-verify-btn" data-user-id="' . $user['id'] . '">Blue Verify</button>';
                    echo '<button class="black-verify-btn" data-user-id="' . $user['id'] . '">Black Verify</button>';
                    echo '<button class="pink-verify-btn" data-user-id="' . $user['id'] . '">Pink Verify</button>';
                } elseif ($user['verified'] == 3) {
                    echo '<button class="unverify-btn" data-user-id="' . $user['id'] . '">Unverify</button>';
                    echo '<button class="blue-verify-btn" data-user-id="' . $user['id'] . '">Blue Verify</button>';
                    echo '<button class="gold-verify-btn" data-user-id="' . $user['id'] . '">Gold Verify</button>';
                    echo '<button class="pink-verify-btn" data-user-id="' . $user['id'] . '">Pink Verify</button>';
                } elseif ($user['verified'] == 4) {
                    echo '<button class="unverify-btn" data-user-id="' . $user['id'] . '">Unverify</button>';
                    echo '<button class="blue-verify-btn" data-user-id="' . $user['id'] . '">Blue Verify</button>';
                    echo '<button class="gold-verify-btn" data-user-id="' . $user['id'] . '">Gold Verify</button>';
                    echo '<button class="black-verify-btn" data-user-id="' . $user['id'] . '">Black Verify</button>';
                }

                echo '</div>';
            }
        } else {
            echo '<p>No users found.</p>';
        }
        ?>
    </div>
</div>

<script>
$(document).ready(function() {
    // Function to show alert
    function showAlert(status, message) {
        var alertBox = $("#alert-box");
        alertBox.removeClass("success error").addClass(status).text(message).fadeIn();

        setTimeout(function() {
            alertBox.fadeOut();
        }, 3000); // Hide after 3 seconds
    }

    // Handle blue verify button click
    $(".blue-verify-btn").on("click", function() {
        var userId = $(this).data("user-id");

        $.ajax({
            url: "", // Same file
            type: "POST",
            data: { 
                user_id: userId, 
                action: "blue_verify" 
            },
            success: function(response) {
                var data = JSON.parse(response);
                showAlert(data.status, data.message); // Show alert
                location.reload(); // Reload the page to reflect the changes
            }
        });
    });

    // Handle gold verify button click
    $(".gold-verify-btn").on("click", function() {
        var userId = $(this).data("user-id");

        $.ajax({
            url: "", // Same file
            type: "POST",
            data: { 
                user_id: userId, 
                action: "gold_verify" 
            },
            success: function(response) {
                var data = JSON.parse(response);
                showAlert(data.status, data.message); // Show alert
                location.reload(); // Reload the page to reflect the changes
            }
        });
    });

    // Handle black verify button click
    $(".black-verify-btn").on("click", function() {
        var userId = $(this).data("user-id");

        $.ajax({
            url: "", // Same file
            type: "POST",
            data: { 
                user_id: userId, 
                action: "black_verify" 
            },
            success: function(response) {
                var data = JSON.parse(response);
                showAlert(data.status, data.message); // Show alert
                location.reload(); // Reload the page to reflect the changes
            }
        });
    });

    // Handle pink verify button click
    $(".pink-verify-btn").on("click", function() {
        var userId = $(this).data("user-id");

        $.ajax({
            url: "", // Same file
            type: "POST",
            data: { 
                user_id: userId, 
                action: "pink_verify" 
            },
            success: function(response) {
                var data = JSON.parse(response);
                showAlert(data.status, data.message); // Show alert
                location.reload(); // Reload the page to reflect the changes
            }
        });
    });

    // Handle unverify button click
    $(".unverify-btn").on("click", function() {
        var userId = $(this).data("user-id");

        $.ajax({
            url: "", // Same file
            type: "POST",
            data: { 
                user_id: userId, 
                action: "unverify" 
            },
            success: function(response) {
                var data = JSON.parse(response);
                showAlert(data.status, data.message); // Show alert
                location.reload(); // Reload the page to reflect the changes
            }
        });
    });
});
</script>

</body>
</html>
