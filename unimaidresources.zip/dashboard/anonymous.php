<?php
// Assuming you've included your database connection file
require_once 'db_connection.php';

// Initialize variables for the form
$content = '';
$imagePath = '';

// Handle form submission if POST request is made
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Get the post content
    $content = $_POST['content'];

    // Handle image upload if provided
    if (isset($_FILES['image']) && $_FILES['image']['error'] == 0) {
        $image = $_FILES['image'];

        // Generate a unique filename for the image
        $imageExtension = pathinfo($image['name'], PATHINFO_EXTENSION);
        $imageName = uniqid() . '.' . $imageExtension;

        // Set the upload directory
        $uploadDir = 'uploads/';
        $uploadPath = $uploadDir . $imageName;

        // Check if upload directory exists, if not, create it
        if (!is_dir($uploadDir)) {
            mkdir($uploadDir, 0777, true);
        }

        // Move the uploaded file to the server
        if (move_uploaded_file($image['tmp_name'], $uploadPath)) {
            $imagePath = $uploadPath;
        } else {
            echo "Error uploading image.";
            exit;
        }
    }

    // Insert post content and image path into the database
    $sql = "INSERT INTO anonymous_posts (content, image_path) VALUES (?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ss", $content, $imagePath);

    if ($stmt->execute()) {
        $postSuccess = true; // Flag to indicate that the post was submitted successfully
    } else {
        echo "Error submitting post.";
    }
}

// Fetch all posts from the database
$sql = "SELECT * FROM anonymous_posts ORDER BY created_at DESC";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Anonymous Post</title>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&display=swap" rel="stylesheet">
    <style>
        body {
            font-family: 'Roboto', sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f7fc;
            color: #333;
        }

        .container {
            max-width: 800px;
            margin: 50px auto;
            padding: 20px;
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
        }

        h2 {
            text-align: center;
            margin-bottom: 20px;
        }

        textarea {
            width: 100%;
            height: 150px;
            padding: 10px;
            border-radius: 4px;
            border: 1px solid #ddd;
            resize: none;
            margin-bottom: 20px;
            font-size: 16px;
            box-sizing: border-box;
        }

        input[type="file"] {
            margin-bottom: 20px;
        }

        button {
            padding: 10px 20px;
            border: none;
            background-color: purple;
            color: white;
            font-size: 16px;
            cursor: pointer;
            border-radius: 4px;
        }

        button:hover {
            background-color: black;
        }

        .post {
            background-color: #fff;
            padding: 15px;
            margin-top: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
        }

        .post img {
            max-width: 100%;
            height: auto;
            margin-top: 10px;
        }

        .anonymous-label {
            font-style: italic;
            color: #999;
            font-size: 14px;
            text-align: center;
            margin-top: 10px;
        }

        .alert {
            padding: 10px;
            background-color: #4CAF50;
            color: white;
            text-align: center;
            margin-bottom: 20px;
            border-radius: 4px;
            display: none;
        }
    </style>
</head>
<body>

<div class="container">
    <h2>Post Anonymously</h2>

    <!-- Anonymous Post Form -->
    <form action="" method="POST" enctype="multipart/form-data">
        <textarea name="content" placeholder="Write your anonymous post here..." required><?php echo htmlspecialchars($content); ?></textarea>
        <input type="file" name="image" accept="image/*">
        <button type="submit">Submit Post</button>
    </form>

    <?php if (isset($postSuccess) && $postSuccess): ?>
        <div class="alert">Post submitted successfully!</div>
    <?php endif; ?>

    <!-- Display all posts -->
    <?php
    if ($result->num_rows > 0) {
        while ($post = $result->fetch_assoc()) {
            echo '<div class="post">';
            echo '<p>' . htmlspecialchars($post['content']) . '</p>';
            if ($post['image_path']) {
                echo '<img src="' . htmlspecialchars($post['image_path']) . '" alt="Post Image">';
            }
            echo '<p class="anonymous-label">Posted Anonymously</p>';
            echo '</div>';
        }
    } else {
        echo '<p>No posts available.</p>';
    }
    ?>
</div>

</body>
</html>
