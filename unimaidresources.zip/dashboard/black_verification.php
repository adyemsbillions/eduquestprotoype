<?php
session_start(); // Start the session to access user info

// Assuming user ID is stored in the session after login
if (!isset($_SESSION['user_id'])) {
    echo "<p class='error'>Please log in to access this page.</p>";
    exit; // Stop the script if the user is not logged in
}

$user_id = $_SESSION['user_id'];

include('db_connection.php'); // Assuming the DB connection file

// Query to check if the user is verified and their gender
$sql = "SELECT verified, gender FROM users WHERE id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$stmt->bind_result($verified, $gender);
$stmt->fetch();
$stmt->close();

// Normalize the gender value by trimming spaces and converting to lowercase
$gender = strtolower(trim($gender));

// Check if the user is verified and if their gender is male
if ($verified != 1) {
    echo "<p class='error'>You must be verified to get a black verification.</p>";
} elseif ($gender !== 'male') {
    echo "<p class='error'>Only male students are eligible for black verification.</p>";
} else {
    // If verified and male, display the black verification page
    echo "<h1 class='header'>Black Verification</h1>";
    echo "<p class='success'>You are eligible for black verification!</p>";
    
    // Button to request black verification
    echo "<form action='request_verification.php' method='POST' class='verification-form'>
            <input type='submit' value='Request Black Verification' class='submit-btn' />
          </form>";
}

// Close the connection
$conn->close();
?>

<!-- Add some basic CSS styles for a clean look -->
<style>
    /* Basic styling for the body */
    body {
        font-family: Arial, sans-serif;
        background-color: #f4f4f4;
        color: #333;
        margin: 0;
        padding: 0;
        display: flex;
        justify-content: center;
        align-items: flex-start;
        flex-direction: column;
        height: 100vh;
        box-sizing: border-box;
    }

    /* Container to center the content and provide spacing */
    .container {
        background-color: white;
        border-radius: 8px;
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        padding: 20px;
        max-width: 400px;
        width: 100%;
        text-align: center;
        box-sizing: border-box;
        margin-top: 20px;
    }

    /* Header style */
    .header {
        color: #212121;
        font-size: 28px;
        margin-bottom: 20px;
        word-wrap: break-word;
    }

    /* Error message style */
    .error {
        background-color: #ffcccc;
        color: #cc0000;
        padding: 10px;
        border-radius: 5px;
        margin: 10px 0;
        font-size: 16px;
        word-wrap: break-word;
    }

    /* Success message style */
    .success {
        background-color: #d4edda;
        color: #155724;
        padding: 10px;
        border-radius: 5px;
        margin: 10px 0;
        font-size: 16px;
        word-wrap: break-word;
    }

    /* Form and button styling */
    .verification-form {
        margin-top: 20px;
        display: block;
        width: 100%;
        margin-bottom: 20px;
    }

    .submit-btn {
        background-color: #212121; /* Black color for button */
        color: white;
        border: none;
        padding: 12px 20px;
        font-size: 16px;
        border-radius: 5px;
        cursor: pointer;
        transition: background-color 0.3s ease;
        width: 100%; /* Make the button take up the full width */
        box-sizing: border-box;
    }

    .submit-btn:hover {
        background-color: #424242;
    }

    .container p {
        font-size: 18px;
        margin: 10px 0;
    }

    /* Make the page responsive */
    @media screen and (max-width: 768px) {
        /* Adjust container width and text for smaller screens */
        .container {
            padding: 15px;
            max-width: 90%;
        }

        .header {
            font-size: 24px;
        }

        .error, .success {
            font-size: 14px;
            padding: 8px;
        }

        .submit-btn {
            padding: 10px 15px;
            font-size: 14px;
        }

        .container p {
            font-size: 16px;
        }
    }

    @media screen and (max-width: 480px) {
        /* Further adjustments for very small screens */
        .container {
            padding: 10px;
            max-width: 95%;
        }

        .header {
            font-size: 20px;
        }

        .error, .success {
            font-size: 12px;
            padding: 6px;
        }

        .submit-btn {
            padding: 8px 12px;
            font-size: 12px;
        }

        .container p {
            font-size: 14px;
        }
    }
</style>
