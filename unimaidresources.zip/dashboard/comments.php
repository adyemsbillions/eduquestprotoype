<?php
include 'db_connection.php';
session_start();

// Ensure the post ID is set
if (!isset($_GET['post_id'])) {
    die('Post ID is required');
}

$post_id = $_GET['post_id'];

// Query to fetch post details
$query = "SELECT fpost.content AS post_content, fpost.timestamp AS post_timestamp, 
                 fpost.image_path AS post_image, users.username, users.club
          FROM fpost 
          JOIN users ON fpost.user_id = users.id
          WHERE fpost.id = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("i", $post_id);
$stmt->execute();
$post_result = $stmt->get_result();
$post = $post_result->fetch_assoc();

// Handle comment posting with image upload
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['comment_content'])) {
    $comment_content = $_POST['comment_content'];
    $user_id = $_SESSION['user_id']; // assuming the user is logged in

    // Handle image upload for the comment
    $image_path = null;
    if (isset($_FILES['comment_image']) && $_FILES['comment_image']['error'] == 0) {
        $image_name = $_FILES['comment_image']['name'];
        $image_tmp = $_FILES['comment_image']['tmp_name'];
        $image_ext = pathinfo($image_name, PATHINFO_EXTENSION);
        $image_path = 'uploads/comments/' . uniqid() . '.' . $image_ext;

        // Move the uploaded file to the server
        move_uploaded_file($image_tmp, $image_path);
    }

    // Insert the comment into the database
    $stmt = $conn->prepare("INSERT INTO fcomment (content, user_id, post_id, image_path) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("siss", $comment_content, $user_id, $post_id, $image_path);
    $stmt->execute();
}

// Handle reply posting
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['reply_content'], $_POST['comment_id'])) {
    $reply_content = $_POST['reply_content'];
    $user_id = $_SESSION['user_id']; // assuming the user is logged in
    $comment_id = $_POST['comment_id']; // ID of the comment being replied to

    // Handle image upload for the reply
    $image_path = null;
    if (isset($_FILES['reply_image']) && $_FILES['reply_image']['error'] == 0) {
        $image_name = $_FILES['reply_image']['name'];
        $image_tmp = $_FILES['reply_image']['tmp_name'];
        $image_ext = pathinfo($image_name, PATHINFO_EXTENSION);
        $image_path = 'uploads/replies/' . uniqid() . '.' . $image_ext;

        // Move the uploaded file to the server
        move_uploaded_file($image_tmp, $image_path);
    }

    // Insert the reply into the database with parent_id
    $stmt = $conn->prepare("INSERT INTO fcomment (content, user_id, post_id, parent_id, image_path) VALUES (?, ?, ?, ?, ?)");
    $stmt->bind_param("siiis", $reply_content, $user_id, $post_id, $comment_id, $image_path);
    $stmt->execute();
}

// Query to fetch all comments for this post
$query = "SELECT fcomment.content AS comment_content, fcomment.timestamp AS comment_timestamp, 
                 fcomment.image_path AS comment_image, fcomment.id AS comment_id, users.username
          FROM fcomment
          JOIN users ON fcomment.user_id = users.id
          WHERE fcomment.post_id = ? AND fcomment.parent_id IS NULL
          ORDER BY fcomment.timestamp DESC";
$stmt = $conn->prepare($query);
$stmt->bind_param("i", $post_id);
$stmt->execute();
$comments_result = $stmt->get_result();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Post Comments</title>
    <style>
    /* Reset basic styles */
* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}

/* Body styling */
body {
    font-family: 'Arial', sans-serif;
    background-color: #f7f7f7;
    color: #333;
    line-height: 1.6;
}

/* Main container */
.container {
    max-width: 900px;
    margin: 30px auto;
    padding: 30px;
    background-color: #fff;
    border-radius: 8px;
    box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
}

/* Header styling */
h1 {
    text-align: center;
    font-size: 28px;
    color: #333;
    margin-bottom: 20px;
}

/* Post styling */
.post {
    background-color: #ffffff;
    padding: 20px;
    border-radius: 8px;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
    margin-bottom: 30px;
}

.post h2 {
    font-size: 22px;
    color: #0078d4;
}

.post .username {
    font-weight: bold;
    font-size: 18px;
    color: #0078d4;
}

.post .timestamp {
    font-size: 0.9em;
    color: #777;
}

.post .content {
    margin-top: 15px;
    font-size: 16px;
    line-height: 1.6;
}

/* Post image styling */
.post img {
    width: 100%;
    height: auto;
    margin-top: 20px;
    border-radius: 8px;
}

/* Comment form styling */
.comment-form {
    margin-top: 20px;
}

.comment-form textarea {
    width: 100%;
    padding: 12px;
    font-size: 16px;
    border-radius: 8px;
    border: 1px solid #ddd;
    resize: vertical;
    margin-bottom: 15px;
    background-color: #f9f9f9;
}

.comment-form input[type="file"] {
    margin-bottom: 15px;
}

.comment-form button {
    background-color: #0078d4;
    color: white;
    border: none;
    padding: 10px 20px;
    border-radius: 5px;
    font-size: 16px;
    cursor: pointer;
    width: 100%;
    transition: background-color 0.3s ease;
}

.comment-form button:hover {
    background-color: #005fa3;
}

/* Comment styling */
.comment {
    margin-top: 25px;
    padding: 20px;
    background: #ffffff;
    border-radius: 8px;
    box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
    position: relative;
}

.comment .username {
    font-weight: bold;
    color: #0078d4;
    font-size: 16px;
}

.comment .timestamp {
    font-size: 0.85em;
    color: #777;
}

.comment .content {
    margin-top: 12px;
    font-size: 14px;
    line-height: 1.5;
}

.comment img {
    max-width: 100%;
    height: auto;
    margin-top: 12px;
    border-radius: 8px;
}

/* Reply form styling */
.reply-form {
    margin-top: 20px;
}

.reply-form textarea {
    width: 100%;
    padding: 12px;
    font-size: 14px;
    border-radius: 8px;
    border: 1px solid #ddd;
    resize: vertical;
    margin-bottom: 15px;
    background-color: #f9f9f9;
}

.reply-form input[type="file"] {
    margin-bottom: 15px;
}

.reply-form button {
    background-color: #0078d4;
    color: white;
    border: none;
    padding: 8px 20px;
    border-radius: 5px;
    font-size: 14px;
    cursor: pointer;
    width: 100%;
    transition: background-color 0.3s ease;
}

.reply-form button:hover {
    background-color: #005fa3;
}

/* Reply styling */
.reply {
    margin-top: 15px;
    margin-left: 40px;
    padding: 15px;
    background-color: #f9f9f9;
    border-radius: 8px;
    box-shadow: 0 2px 5px rgba(0, 0, 0, 0.05);
}

.reply .username {
    font-weight: bold;
    color: #0078d4;
}

.reply .timestamp {
    font-size: 0.85em;
    color: #777;
}

.reply .content {
    margin-top: 12px;
    font-size: 14px;
    line-height: 1.5;
}

.reply img {
    max-width: 100%;
    height: auto;
    margin-top: 12px;
    border-radius: 8px;
}

/* Media Queries for responsiveness */
@media (max-width: 768px) {
    .container {
        padding: 20px;
    }

    h1 {
        font-size: 26px;
    }

    .post h2 {
        font-size: 20px;
    }

    .comment-form textarea,
    .reply-form textarea {
        font-size: 14px;
    }

    .comment-form button,
    .reply-form button {
        font-size: 14px;
    }

    .comment, .reply {
        padding: 15px;
    }

    .comment-form {
        margin-top: 15px;
    }

    .reply-form {
        margin-top: 15px;
    }
}

    </style>
</head>
<body>

<div class="container">
    <h1>Comments on Post</h1>

    <!-- Displaying the post -->
    <div class="post">
        <h2><?php echo htmlspecialchars($post['username']); ?> - <?php echo htmlspecialchars($post['club']); ?></h2>
        <p class="content"><?php echo nl2br(htmlspecialchars($post['post_content'])); ?></p>

        <!-- Display image if available -->
        <?php if ($post['post_image']): ?>
            <img src="<?php echo htmlspecialchars($post['post_image']); ?>" alt="Post Image">
        <?php endif; ?>

        <span class="timestamp"><?php echo $post['post_timestamp']; ?></span>
    </div>

    <!-- Comment Form -->
    <form method="POST" enctype="multipart/form-data" class="comment-form">
        <textarea name="comment_content" placeholder="Write your comment..." required></textarea>
        <input type="file" name="comment_image" accept="image/*">
        <button type="submit">Post Comment</button>
    </form>

    <!-- Displaying Comments -->
    <div class="comments">
        <?php while ($comment = $comments_result->fetch_assoc()): ?>
            <div class="comment">
                <h3 class="username"><?php echo htmlspecialchars($comment['username']); ?></h3>
                <span class="timestamp"><?php echo $comment['comment_timestamp']; ?></span>
                <p class="content"><?php echo nl2br(htmlspecialchars($comment['comment_content'])); ?></p>

                <!-- Display comment image if available -->
                <?php if ($comment['comment_image']): ?>
                    <img src="<?php echo htmlspecialchars($comment['comment_image']); ?>" alt="Comment Image">
                <?php endif; ?>

                <!-- Reply Form -->
                <form method="POST" enctype="multipart/form-data" class="reply-form">
                    <textarea name="reply_content" placeholder="Write your reply..." required></textarea>
                    <input type="file" name="reply_image" accept="image/*">
                    <button type="submit">Reply</button>
                    <input type="hidden" name="comment_id" value="<?php echo $comment['comment_id']; ?>">
                </form>

                <!-- Displaying Replies -->
                <?php
                    $query_replies = "SELECT fcomment.content AS reply_content, fcomment.timestamp AS reply_timestamp, 
                                         fcomment.image_path AS reply_image, users.username 
                                      FROM fcomment 
                                      JOIN users ON fcomment.user_id = users.id 
                                      WHERE fcomment.parent_id = ? 
                                      ORDER BY fcomment.timestamp ASC";
                    $stmt_replies = $conn->prepare($query_replies);
                    $stmt_replies->bind_param("i", $comment['comment_id']);
                    $stmt_replies->execute();
                    $replies_result = $stmt_replies->get_result();
                    while ($reply = $replies_result->fetch_assoc()):
                ?>
                    <div class="reply">
                        <h4 class="username"><?php echo htmlspecialchars($reply['username']); ?></h4>
                        <span class="timestamp"><?php echo $reply['reply_timestamp']; ?></span>
                        <p class="content"><?php echo nl2br(htmlspecialchars($reply['reply_content'])); ?></p>

                        <!-- Display reply image if available -->
                        <?php if ($reply['reply_image']): ?>
                            <img src="<?php echo htmlspecialchars($reply['reply_image']); ?>" alt="Reply Image">
                        <?php endif; ?>
                    </div>
                <?php endwhile; ?>
            </div>
        <?php endwhile; ?>
    </div>
</div>

</body>
</html>
