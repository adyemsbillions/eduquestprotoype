<?php
session_start(); // Start the session to access session variables

// Check if the user is logged in by checking the session
if (!isset($_SESSION['user_id'])) {
    die("You need to log in first.");
}

// Handle the form submission for creating a group
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get the form data
    $groupName = $_POST['group_name'];
    $groupDescription = $_POST['group_description'];
    $isPublic = isset($_POST['is_public']) ? 1 : 0; // Default to private if not set

    // Get the logged-in user ID (creator of the group)
    $userId = $_SESSION['user_id'];

    // Database connection
    $conn = new mysqli('localhost', 'root', '', 'unimaidconnect');

    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Insert the group into the `groups` table
    $sql = "INSERT INTO groups (name, description, creator_id, is_public) 
            VALUES ('$groupName', '$groupDescription', '$userId', '$isPublic')";
    
    if ($conn->query($sql) === TRUE) {
        // Redirect to the dashboard or group page after success
        echo "Group created successfully.";
        // You can also redirect like this:
        // header("Location: group_page.php?group_id=" . $conn->insert_id);
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }

    $conn->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Create a Group</title>
    <style>
        /* General body styling */
body {
    font-family: 'Arial', sans-serif;
    background-color: #f7f7f7;
    margin: 0;
    padding: 0;
    color: #333;
}

/* Container to center the form */
.container {
    max-width: 600px;
    margin: 30px auto;
    background-color: #fff;
    padding: 30px;
    box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
    border-radius: 8px;
    text-align: center;
}

/* Header style */
h1 {
    font-size: 24px;
    margin-bottom: 20px;
    color: #444;
}

/* Form layout */
form {
    display: flex;
    flex-direction: column;
    align-items: stretch;
}

/* Label and inputs */
label {
    font-size: 14px;
    color: #444;
    margin-bottom: 8px;
    text-align: left;
}

input[type="text"],
textarea,
input[type="checkbox"] {
    padding: 12px;
    font-size: 14px;
    margin-bottom: 20px;
    border-radius: 5px;
    border: 1px solid #ddd;
    outline: none;
    width: 100%;
    box-sizing: border-box;
}

textarea {
    resize: vertical;
    min-height: 120px;
}

input[type="checkbox"] {
    width: auto;
    margin-right: 10px;
    margin-top: 10px;
}

/* Submit button */
input[type="submit"] {
    background-color: purple;
    color: #fff;
    font-size: 16px;
    padding: 12px;
    border: none;
    border-radius: 5px;
    cursor: pointer;
    transition: background-color 0.3s ease;
    width: 100%;
}

input[type="submit"]:hover {
    background-color: purple    ;
}

/* Responsive Design */
@media (max-width: 768px) {
    .container {
        width: 90%;
        padding: 15px;
    }

    h1 {
        font-size: 20px;
    }

    input[type="text"],
    textarea,
    input[type="submit"] {
        font-size: 16px;
    }

    input[type="checkbox"] {
        margin-left: 10px;
    }
}

    </style>
</head>
<body>
<div class="container">
        <h1>Create a Group</h1>
        <form action="create_groups.php" method="POST">
            <label for="group_name">Group Name:</label>
            <input type="text" name="group_name" id="group_name" required><br><br>

            <label for="group_description">Group Description:</label>
            <textarea name="group_description" id="group_description" required></textarea><br><br>

            <label for="is_public">Make this group public:</label>
            <input type="checkbox" name="is_public" id="is_public"><br><br>

            <input type="submit" value="Create Group">
        </form>
    </div>

</body>
</html>
