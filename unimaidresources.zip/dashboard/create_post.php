    <?php
    // Start the session
    session_start();

    // Include the database connection (adjust the path as needed)
    include 'db_connection.php'; // Make sure your connection file is correct

    // Check if user is logged in
    if (!isset($_SESSION['user_id'])) {
        echo "User is not logged in!";
        exit();
    }

    // Get the user ID from the session
    $user_id = $_SESSION['user_id'];

    // Sanitize post content
    $post_content = $_POST['post_content'] ?? '';

    // Initialize variables for media
    $media_url = null;
    $media_type = 'none';

    // File handling for media
    if (isset($_FILES['media']) && $_FILES['media']['error'] === 0) {
        // Collect file info
        $file = $_FILES['media'];
        $file_name = $file['name'];
        $file_tmp_name = $file['tmp_name'];
        $file_size = $file['size'];
        $file_error = $file['error'];

        // Check for file size (max 5MB)
        if ($file_size > 5000000) {
            echo "File size too large. Max 5MB allowed.";
            exit();
        }

        // Get file extension
        $file_ext = strtolower(pathinfo($file_name, PATHINFO_EXTENSION));
        $allowed_ext = ['jpg', 'jpeg', 'png', 'gif', 'mp4', 'avi', 'mov'];

        // Validate the file extension
        if (!in_array($file_ext, $allowed_ext)) {
            echo "Invalid file type. Allowed types: image (jpg, jpeg, png, gif) and video (mp4, avi, mov).";
            exit();
        }

        // Define the upload directory
        $upload_dir = 'uploads/';

        // Ensure the file name is safe (avoid special characters)
        $safe_file_name = preg_replace("/[^a-zA-Z0-9\._-]/", "_", $file_name);
        $file_path = $upload_dir . $safe_file_name;

        // Move the uploaded file to the server
        if (move_uploaded_file($file_tmp_name, $file_path)) {
            // Determine media type (image or video)
            if (in_array($file_ext, ['jpg', 'jpeg', 'png', 'gif'])) {
                $media_type = 'image';
            } elseif (in_array($file_ext, ['mp4', 'avi', 'mov'])) {
                $media_type = 'video';
            }
            $media_url = $file_path; // Store the file URL in the database
        } else {
            echo "Error uploading the file.";
            exit();
        }
    }

    // Prepare the SQL query to insert the post
    $sql = "INSERT INTO posts (user_id, post_content, media_url, media_type) VALUES (?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("isss", $user_id, $post_content, $media_url, $media_type);

    // Execute the query and check for errors
    if ($stmt->execute()) {
    header("location: dashboard.php");
    } else {
        echo "Error: " . $stmt->error;
    }

    // Close the statement and connection
    $stmt->close();
    $conn->close();
    ?>
