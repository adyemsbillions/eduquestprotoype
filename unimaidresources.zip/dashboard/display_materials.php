<?php
// Include the database connection
include('db_connection.php');

// Default values for search and filter
$search_query = '';
$filter = 'handouts'; // Default to 'handouts'

if (isset($_GET['search'])) {
    $search_query = $_GET['search'];
}

if (isset($_GET['category'])) {
    $filter = $_GET['category'];
}

// Prepare query to fetch data based on search and filter
$query = "SELECT * FROM $filter WHERE title LIKE '%$search_query%'";

// Execute the query
$result = $conn->query($query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Handout Download Site</title>
    <style>
        /* General Styling */
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 20px;
        }

        /* Search Bar */
        .search-bar {
            display: flex;
            flex-wrap: wrap;
            justify-content: space-between;
            align-items: center;
            margin: 20px 0;
            padding: 15px;
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }
        .search-bar input[type="text"],
        .search-bar select,
        .search-bar button {
            padding: 12px;
            font-size: 16px;
            border-radius: 6px;
            border: 1px solid #ccc;
            background-color: #f9f9f9;
        }
        .search-bar input[type="text"],
        .search-bar select {
            width: 48%;
        }
        .search-bar button {
            width: 20%;
            background-color: purple;
            color: white;
            border: none;
            cursor: pointer;
            font-size: 16px;
        }
        .search-bar button:hover {
            background-color: #0056b3;
        }

        /* Results Section */
        .results {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
            gap: 20px;
            margin-top: 30px;
        }

        /* Card Styling */
        .card {
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 2px 6px rgba(0, 0, 0, 0.1);
            padding: 20px;
            display: flex;
            flex-direction: column;
            align-items: center;
            text-align: center;
        }
        .card img {
            max-width: 100%;
            height: auto;
            border-radius: 8px;
            margin-bottom: 15px;
        }
        .card-title {
            font-size: 20px;
            font-weight: bold;
            margin-top: 15px;
        }
        .card-note {
            font-size: 14px;
            color: #555;
            margin: 10px 0;
        }
        .card a {
            text-decoration: none;
            background-color: purple;
            color: white;
            padding: 10px 20px;
            border-radius: 6px;
            font-weight: bold;
            transition: background-color 0.3s;
        }
        .card a:hover {
            background-color: #218838;
        }

        /* Floating Upload Button */
        .floating-button {
            position: fixed;
            bottom: 20px;
            right: 20px;
            background-color: purple;
            color: white;
            border: none;
            padding: 15px 25px;
            font-size: 16px;
            border-radius: 45%;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
            cursor: pointer;
            text-align: center;
            transition: background-color 0.3s;
        }
        .floating-button:hover {
            background-color: #0056b3;
        }

        /* Responsive Design */
        @media (max-width: 1024px) {
            .search-bar {
                flex-direction: column;
                align-items: stretch;
            }
            .search-bar input[type="text"],
            .search-bar select {
                width: 100%;
                margin-bottom: 10px;
            }
            .search-bar button {
                width: 100%;
                margin-top: 10px;
            }

            .results {
                grid-template-columns: repeat(auto-fill, minmax(250px, 1fr));
            }

            .floating-button {
                padding: 12px 20px;
                font-size: 14px;
            }
        }

        @media (max-width: 768px) {
            .results {
                grid-template-columns: 1fr;
            }

            .floating-button {
                padding: 10px 18px;
                font-size: 14px;
            }
        }

        @media (max-width: 480px) {
            .search-bar input[type="text"],
            .search-bar select {
                width: 100%;
            }

            .search-bar button {
                width: 100%;
            }

            .card {
                padding: 15px;
            }

            .card-title {
                font-size: 18px;
            }

            .card-note {
                font-size: 12px;
            }

            .floating-button {
                padding: 12px 20px;
                font-size: 14px;
            }
        }
    </style>
</head>
<body>

<div class="container">
    <div class="search-bar">
        <form method="GET" style="width: 100%; display: flex; flex-wrap: wrap;">
            <input type="text" name="search" placeholder="Search..." value="<?= htmlspecialchars($search_query) ?>">
           
           <br> <br>
            <select name="category">
                <option value="handouts" <?= ($filter == 'handouts') ? 'selected' : '' ?>>Handouts</option>
                <option value="past_questions" <?= ($filter == 'past_questions') ? 'selected' : '' ?>>Past Questions</option>
                <option value="summaries" <?= ($filter == 'summaries') ? 'selected' : '' ?>>Summaries</option>
            </select>
            <button type="submit">Search</button>
        </form>
    </div>

    <div class="results">
        <?php if ($result->num_rows > 0): ?>
            <?php while ($row = $result->fetch_assoc()): ?>
                <div class="card">
                    <img src="<?= htmlspecialchars($row['image']) ?>" alt="<?= htmlspecialchars($row['title']) ?>">
                    <div>
                        <div class="card-title"><?= htmlspecialchars($row['title']) ?></div>
                        <div class="card-note"><?= htmlspecialchars($row['note']) ?></div>
                        <a href="<?= htmlspecialchars($row['download_link']) ?>" download>Download</a>
                    </div>
                </div>
            <?php endwhile; ?>
        <?php else: ?>
            <p>No results found.</p>
        <?php endif; ?>
    </div>
</div>

<!-- Floating Button for Upload -->
<a href="upload_handout.php">
    <button class="floating-button">+</button>
</a>

</body>
</html>

<?php
// Close the database connection
$conn->close();
?>
