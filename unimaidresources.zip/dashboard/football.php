<?php
include 'db_connection.php';
session_start();

// Handle post creation (including image upload)
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['post_content'])) {
    $post_content = $_POST['post_content'];
    $user_id = $_SESSION['user_id']; // assuming the user is logged in

    // Handle image upload
    $image_path = null;
    if (isset($_FILES['post_image']) && $_FILES['post_image']['error'] == 0) {
        $image_name = $_FILES['post_image']['name'];
        $image_tmp = $_FILES['post_image']['tmp_name'];
        $image_ext = pathinfo($image_name, PATHINFO_EXTENSION);
        $image_path = 'uploads/' . uniqid() . '.' . $image_ext;

        // Move the uploaded file to the server
        move_uploaded_file($image_tmp, $image_path);
    }

    // Insert post into the database
    $stmt = $conn->prepare("INSERT INTO fpost (content, user_id, image_path) VALUES (?, ?, ?)");
    $stmt->bind_param("sis", $post_content, $user_id, $image_path);
    $stmt->execute();
}

// Query to fetch posts and display them with comment count
$query = "SELECT fpost.content AS post_content, fpost.timestamp AS post_timestamp, fpost.id AS post_id, 
                 fpost.image_path, users.username, users.club,
                 (SELECT COUNT(*) FROM fcomment WHERE post_id = fpost.id) AS comment_count
          FROM fpost 
          JOIN users ON fpost.user_id = users.id 
          ORDER BY fpost.timestamp DESC";
$result = $conn->query($query);

$posts = [];
if ($result) {
    while ($post = $result->fetch_assoc()) {
        $posts[] = $post;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Football Forum</title>
    <style>
/* Base layout */
body {
    font-family: 'Arial', sans-serif;
    margin: 0;
    padding: 0;
    background-color: #f4f4f4;
    display: flex;
    justify-content: center;
    align-items: flex-start;
    min-height: 100vh;
}

.container {
    max-width: 900px;
    width: 100%;
    margin: 20px auto;
    background-color: #ffffff;
    padding: 30px;
    border-radius: 8px;
    box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
    overflow-y: auto;
    height: calc(100vh - 60px);
}

h1 {
    text-align: center;
    color: #333;
    font-size: 28px;
    margin-bottom: 20px;
}

/* Post container */
.posts {
    margin-bottom: 20px;
}

.post {
    margin-bottom: 20px;
    padding: 15px;
    background: #ffffff;
    border-radius: 8px;
    box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
    display: flex;
    flex-direction: column;
    gap: 10px;
}

.post h2 {
    margin: 0;
    font-size: 20px;
    color: #0078d4;
}

.post .username {
    font-weight: bold;
    font-size: 18px;
}

.post .timestamp {
    font-size: 0.85em;
    color: #777;
}

.post .content {
    margin-top: 10px;
    font-size: 16px;
    line-height: 1.5;
}

/* Image styling */
.post img {
    max-width: 100%;
    height: auto;
    border-radius: 8px;
    margin-top: 10px;
}

/* Comment and reply styles */
.comment, .reply {
    margin-left: 30px;
    background-color: #f7f7f7;
    padding: 12px;
    border-radius: 8px;
    margin-top: 10px;
    display: flex;
    flex-direction: column;
    gap: 5px;
}

.comment .username, .reply .username {
    font-weight: bold;
    color: #0078d4;
}

.comment .timestamp, .reply .timestamp {
    font-size: 0.85em;
    color: #888;
}

.comment-form, .reply-form {
    margin-top: 15px;
    display: flex;
    flex-direction: column;
    gap: 10px;
}

/* Textarea and button styling */
.comment-form textarea, .reply-form textarea {
    width: 100%;
    padding: 12px;
    margin-bottom: 10px;
    font-size: 14px;
    border: 1px solid #ddd;
    border-radius: 5px;
    resize: vertical;
    min-height: 50px;
}

.comment-form button, .reply-form button {
    background-color: #0078d4;
    color: white;
    border: none;
    padding: 8px 20px;
    border-radius: 5px;
    cursor: pointer;
    font-size: 14px;
}

.comment-form button:hover, .reply-form button:hover {
    background-color: #005fa3;
}

.show-more {
    color: #0078d4;
    cursor: pointer;
    font-size: 14px;
    margin-top: 10px;
}

/* Post form */
.post-form {
    background: #f4f4f4;
    padding: 20px;
    margin-bottom: 20px;
    border-radius: 8px;
    box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
}

.post-form textarea {
    width: 100%;
    padding: 12px;
    font-size: 14px;
    border: 1px solid #ddd;
    border-radius: 5px;
    resize: vertical;
    box-sizing: border-box;
}

.post-form button {
    background-color: #0078d4;
    color: white;
    border: none;
    padding: 10px 20px;
    border-radius: 5px;
    cursor: pointer;
    font-size: 14px;
}

.post-form button:hover {
    background-color: #005fa3;
}

/* Comment count styling */
.comment-count {
    color: #777;
    font-size: 0.85em;
    margin-top: 5px;
    text-align: right;
}

/* Responsive layout */
@media (max-width: 768px) {
    .container {
        padding: 15px;
    }

    .post {
        padding: 12px;
    }

    .post-form textarea {
        font-size: 13px;
    }

    .comment-form textarea, .reply-form textarea {
        font-size: 13px;
    }

    .post-form button {
        font-size: 12px;
    }
}

    </style>
</head>
<body>

<div class="container">
    <h1>Football Discussion Forum</h1>

    <!-- Post Form -->
    <form method="POST" enctype="multipart/form-data" class="post-form">
        <textarea name="post_content" placeholder="Write your post..." required></textarea>
        <input type="file" name="post_image" accept="image/*">
        <button type="submit">Post</button>
    </form>

    <!-- Displaying posts -->
    <div class="posts">
        <?php foreach ($posts as $post): ?>
            <div class="post">
                <h2 class="username"><?php echo htmlspecialchars($post['username']); ?> - <?php echo htmlspecialchars($post['club']); ?></h2>
                <p class="content"><?php echo nl2br(htmlspecialchars($post['post_content'])); ?></p>

                <!-- Display image if available -->
                <?php if ($post['image_path']): ?>
                    <img src="<?php echo htmlspecialchars($post['image_path']); ?>" alt="Post Image" style="max-width: 100%; height: auto;">
                <?php endif; ?>

                <span class="timestamp"><?php echo $post['post_timestamp']; ?></span>

                <!-- View Comments Button with Comment Count -->
                <a href="comments.php?post_id=<?php echo $post['post_id']; ?>" class="view-comments">
                    View Comments (<?php echo $post['comment_count']; ?>)
                </a>
            </div>
        <?php endforeach; ?>
    </div>
</div>

</body>
</html>
