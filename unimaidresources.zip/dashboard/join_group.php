<?php
session_start(); // Start session

// Ensure user is logged in
if (!isset($_SESSION['user_id'])) {
    die("You need to log in first.");
}

$userId = $_SESSION['user_id']; // Get the logged-in user ID

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get the group ID from the form
    $groupId = $_POST['group_id'];

    // Database connection
    $conn = new mysqli('localhost', 'root', '', 'unimaidconnect');

    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Check if the user is already a member of the group
    $sqlCheck = "SELECT * FROM group_members WHERE group_id = '$groupId' AND user_id = '$userId'";
    $resultCheck = $conn->query($sqlCheck);

    if ($resultCheck->num_rows > 0) {
        echo "<p>You are already a member of this group.</p>";
    } else {
        // Insert into group_members table to join the group
        $sql = "INSERT INTO group_members (group_id, user_id) VALUES ('$groupId', '$userId')";

        if ($conn->query($sql) === TRUE) {
            echo "<p>You have successfully joined the group.</p>";
        } else {
            echo "Error: " . $sql . "<br>" . $conn->error;
        }
    }

    $conn->close();
} else {
    echo "Invalid request.";
}
?>
