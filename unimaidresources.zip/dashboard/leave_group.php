<?php
session_start(); // Start session

// Ensure user is logged in
if (!isset($_SESSION['user_id'])) {
    die("You need to log in first.");
}

$userId = $_SESSION['user_id']; // Get the logged-in user ID

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get the group ID from the form
    $groupId = $_POST['group_id'];

    // Database connection
    $conn = new mysqli('localhost', 'root', '', 'unimaidconnect');

    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Delete the user from the group
    $sql = "DELETE FROM group_members WHERE group_id = '$groupId' AND user_id = '$userId'";

    if ($conn->query($sql) === TRUE) {
        echo "<p>You have left the group.</p>";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }

    $conn->close();
}
?>
