<?php
// Database connection
$conn = new mysqli("localhost", "root", "", "UNIMAIDCONNECT");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetching posts and decoding image paths
$sql_posts = "SELECT mp.post_id, mp.item_name, mp.description, mp.price, mp.images, u.username 
              FROM marketplace_posts mp 
              JOIN users u ON mp.user_id = u.id 
              WHERE mp.status = 'approved' ORDER BY mp.created_at DESC";
$result_posts = $conn->query($sql_posts);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Marketplace</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f9f9f9;
            color: #333;
        }

        .container {
            max-width: 1200px;
            margin: 20px auto;
            padding: 20px;
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            box-sizing: border-box;
        }

        h2 {
            text-align: center;
            margin-bottom: 20px;
        }

        .search-container {
            text-align: center;
            margin-bottom: 20px;
            box-sizing: border-box;
        }

        .post {
            display: flex;
            flex-direction: column;
            margin-bottom: 20px;
            padding: 20px;
            background-color: #fafafa;
            border: 1px solid #ddd;
            border-radius: 8px;
        }

        .post img {
            max-width: 100%;
            height: auto;
            margin: 10px 0;
        }

        .post h3 {
            margin: 0;
            font-size: 24px;
            color: #333;
        }

        .post p {
            margin: 5px 0;
            font-size: 16px;
            color: #666;
        }

        .search-box {
            padding: 8px;
            width: 300px;
            font-size: 16px;
            border-radius: 4px;
            border: 1px solid #ddd;
            box-sizing: border-box;
           
        }

        /* Image grid styling */
        .image-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(150px, 1fr));
            gap: 10px;
        }

        .image-grid img {
            width: 100%;
            height: auto;
            border-radius: 4px;
            cursor: pointer;
            transition: transform 0.3s ease;
        }

        .image-grid img:hover {
            transform: scale(1.05);
        }

        /* Modal styles */
        .modal {
            display: none;
            position: fixed;
            z-index: 1;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.8);
            overflow: auto;
        }

        .modal-content {
            position: relative;
            margin: auto;
            padding: 20px;
            width: 80%;
            max-width: 600px;
            background-color: #fff;
        }

        .modal img {
            width: 100%;
            height: auto;
        }

        .close {
            position: absolute;
            top: 10px;
            right: 10px;
            color: #aaa;
            font-size: 30px;
            font-weight: bold;
            cursor: pointer;
        }

        .close:hover,
        .close:focus {
            color: #000;
            text-decoration: none;
            cursor: pointer;
        }

        /* Mobile view adjustments */
        @media (max-width: 768px) {
            .image-grid {
                display: block;
            }

            .image-grid img {
                display: none;
                max-width: 100%;
                height: auto;
            }

            .image-grid img:first-child {
                display: block; /* Show only the first image initially */
            }

            .post .show-more {
                display: block;
                margin-top: 10px;
                text-align: center;
                color: #6a1b9a;
                cursor: pointer;
            }

            .show-more.active + .image-grid img {
                display: block; /* Reveal images when "Show More" is clicked */
            }
        }
        input{
            box-sizing: border-box;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>Marketplace</h2>

        <div class="search-container">
            <input type="text" id="search-box" class="search-box" placeholder="Search items..." onkeyup="filterPosts()">
        </div>

        <div id="marketplace-posts">
            <?php while ($post = $result_posts->fetch_assoc()): ?>
                <div class="post">
                    <h3><?php echo htmlspecialchars($post['item_name']); ?></h3>
                    <p><?php echo htmlspecialchars($post['description']); ?></p>
                    <p><strong>Price:</strong> $<?php echo number_format($post['price'], 2); ?></p>
                    <p><strong>Posted by:</strong> <?php echo htmlspecialchars($post['username']); ?></p>

                    <!-- Display images for the post in grid -->
                    <div class="image-grid">
                        <?php
                        // Decode the JSON array of image paths
                        $images = json_decode($post['images'], true);
                        if ($images) {
                            foreach ($images as $index => $image_path) {
                                echo '<img src="' . htmlspecialchars($image_path) . '" alt="Item Image" onclick="openModal(\'' . htmlspecialchars($image_path) . '\')" class="image-' . $index . '">';
                            }
                        }
                        ?>
                    </div>

                    <!-- Show More button to reveal additional images -->
                    <div class="show-more" onclick="toggleImages(this)">Show More</div>
                </div>
            <?php endwhile; ?>
        </div>
    </div>

    <!-- Modal -->
    <div id="modal" class="modal">
        <span class="close" onclick="closeModal()">&times;</span>
        <div class="modal-content">
            <img id="modal-image" src="" alt="Large image">
        </div>
    </div>

    <script>
        function filterPosts() {
            var input, filter, posts, post, itemName, i;
            input = document.getElementById('search-box');
            filter = input.value.toLowerCase();
            posts = document.getElementById('marketplace-posts').getElementsByClassName('post');

            for (i = 0; i < posts.length; i++) {
                post = posts[i];
                itemName = post.getElementsByTagName('h3')[0];
                if (itemName.innerText.toLowerCase().indexOf(filter) > -1) {
                    post.style.display = "";
                } else {
                    post.style.display = "none";
                }
            }
        }

        function openModal(imagePath) {
            var modal = document.getElementById("modal");
            var modalImage = document.getElementById("modal-image");
            modal.style.display = "block";
            modalImage.src = imagePath;
        }

        function closeModal() {
            var modal = document.getElementById("modal");
            modal.style.display = "none";
        }

        function toggleImages(button) {
            var post = button.closest('.post');
            var images = post.querySelectorAll('.image-grid img');
            button.classList.toggle('active');
            if (button.classList.contains('active')) {
                button.innerHTML = 'Show Less';
                images.forEach(function(img) {
                    img.style.display = 'block';
                });
            } else {
                button.innerHTML = 'Show More';
                images.forEach(function(img, index) {
                    if (index !== 0) { // Keep only the first image visible
                        img.style.display = 'none';
                    }
                });
            }
        }
    </script>
</body>
</html>
