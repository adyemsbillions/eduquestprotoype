<?php
// Database connection
$conn = new mysqli("localhost", "root", "", "UNIMAIDCONNECT");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Start session and get the logged-in user's ID
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php"); // Redirect to login if not logged in
    exit();
}

$user_id = $_SESSION['user_id'];

// Get user information
$sql_user = "SELECT * FROM users WHERE id = ?";
$stmt = $conn->prepare($sql_user);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$user_result = $stmt->get_result();
$user = $user_result->fetch_assoc();

// Handle profile picture update
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_profile'])) {
    if (isset($_FILES['new_profile_picture']) && $_FILES['new_profile_picture']['error'] == 0) {
        $profilePic = $_FILES['new_profile_picture'];
        $allowedTypes = ['image/jpeg', 'image/png', 'image/gif'];
        $uploadDir = 'uploads/profile_pictures/';  // Directory to save uploaded images

        // Validate file type
        if (!in_array($profilePic['type'], $allowedTypes)) {
            $profileError = "Invalid file type. Please upload a JPG, PNG, or GIF image.";
        } else {
            // Use the original file name without modifying it
            $fileName = basename($profilePic['name']);
            $filePath = $uploadDir . $fileName;

            // Move the uploaded file to the specified directory
            if (move_uploaded_file($profilePic['tmp_name'], $filePath)) {
                // Update the profile picture in the database
                $query = "UPDATE users SET profile_picture = ? WHERE id = ?";
                $stmt_update = $conn->prepare($query);
                $stmt_update->bind_param("si", $filePath, $user_id);
                if ($stmt_update->execute()) {
                    $_SESSION['profile_picture'] = $filePath; // Update session data
                    $profileSuccess = "Profile picture updated successfully.";
                } else {
                    $profileError = "Error updating profile picture.";
                }
            } else {
                $profileError = "Error uploading the profile picture.";
            }
        }
    }
}

// Get the follower count for the user
$sql_followers = "SELECT COUNT(*) AS followers FROM followers WHERE following_id = ?";
$stmt_followers = $conn->prepare($sql_followers);
$stmt_followers->bind_param("i", $user_id);
$stmt_followers->execute();
$followers_result = $stmt_followers->get_result();
$followers_count = $followers_result->fetch_assoc()['followers'];

// Check if the user is already following
$sql_follow_status = "SELECT COUNT(*) AS is_following FROM followers WHERE follower_id = ? AND following_id = ?";
$stmt_follow_status = $conn->prepare($sql_follow_status);
$stmt_follow_status->bind_param("ii", $user_id, $user['id']);
$stmt_follow_status->execute();
$follow_status_result = $stmt_follow_status->get_result();
$follow_status = $follow_status_result->fetch_assoc()['is_following'];

// Handle Follow/Unfollow action via AJAX
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['follow'])) {
    $action = $_POST['follow_action']; // Either "follow" or "unfollow"

    if ($action === 'follow') {
        // Follow the user
        $sql_follow = "INSERT INTO followers (follower_id, following_id) VALUES (?, ?)";
        $stmt_follow = $conn->prepare($sql_follow);
        $stmt_follow->bind_param("ii", $user_id, $user['id']);
        if ($stmt_follow->execute()) {
            // Return updated follower count and button text
            $sql_followers = "SELECT COUNT(*) AS followers FROM followers WHERE following_id = ?";
            $stmt_followers = $conn->prepare($sql_followers);
            $stmt_followers->bind_param("i", $user_id);
            $stmt_followers->execute();
            $followers_result = $stmt_followers->get_result();
            $followers_count = $followers_result->fetch_assoc()['followers'];

            echo json_encode(['status' => 'success', 'followers_count' => $followers_count, 'button_text' => 'Unfollow']);
        } else {
            echo json_encode(['status' => 'error']);
        }
    } elseif ($action === 'unfollow') {
        // Unfollow the user
        $sql_unfollow = "DELETE FROM followers WHERE follower_id = ? AND following_id = ?";
        $stmt_unfollow = $conn->prepare($sql_unfollow);
        $stmt_unfollow->bind_param("ii", $user_id, $user['id']);
        if ($stmt_unfollow->execute()) {
            // Return updated follower count and button text
            $sql_followers = "SELECT COUNT(*) AS followers FROM followers WHERE following_id = ?";
            $stmt_followers = $conn->prepare($sql_followers);
            $stmt_followers->bind_param("i", $user_id);
            $stmt_followers->execute();
            $followers_result = $stmt_followers->get_result();
            $followers_count = $followers_result->fetch_assoc()['followers'];

            echo json_encode(['status' => 'success', 'followers_count' => $followers_count, 'button_text' => 'Follow']);
        } else {
            echo json_encode(['status' => 'error']);
        }
    }
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">

    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Profile</title>
    <style>
        body {
            background-color: #f9f9f9;
            color: #333;
            padding: 20px;
        }

        .container {
            max-width: 800px;
            margin: 0 auto;
            background-color: #fff;
            padding: 30px;
            border-radius: 8px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }

        .profile-img {
            width: 100px;
            height: 100px;
            object-fit: cover;
            border-radius: 50%;
        }

        button {
            background-color: #6a1b9a;
            color: white;
            padding: 10px 15px;
            font-size: 16px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }

        button:hover {
            background-color: #8e24aa;
        }

        .error, .success {
            color: red;
            font-size: 14px;
            margin-bottom: 10px;
        }

        .success {
            color: green;
        }

        #follow-button {
            margin-top: 20px;
        }

        .verified {
            color: green;
            font-weight: bold;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>Your Profile</h2>
  
<style>
    .verified-badge {
  position: relative;
  font-size: 18px;
color:blue;
}

.verified-badge .fa-check {
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  font-size: 12px; /* Adjust the checkmark size */
  color: white;   /* Set the checkmark color */
  
}
p{
    font-weight: bold;
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
}
h2{
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif    ;
}
</style>
        <!-- Display username and verification status -->
     

        <img class="avatar-img max-un" src="/unimaidconnect/dashboard/<?php echo htmlspecialchars($user['profile_picture']); ?>" alt="avatar" style="width: 60px; height: 60px; object-fit: cover; border-radius: 10px;">
        <form method="POST" enctype="multipart/form-data">
            <input type="file" name="new_profile_picture" accept="image/*">
            <p><strong>Username:</strong> <?php echo htmlspecialchars($user['username']); ?>
        <?php if ($user['verified'] == 1): ?>
            <span class="fa fa-circle verified-badge" title="Verified User">
  <span class="fa fa-check"></span>
</span>
        <?php endif; ?>
        </p>
        <p>Followers: <span id="followers-count"><?php echo $followers_count; ?></span></p>
       
            <br><br>
            <button type="submit" name="update_profile">Update Profile Picture</button>
        </form>

        <?php if (isset($profileError)): ?>
            <div class="error"><?php echo $profileError; ?></div>
        <?php endif; ?>
        <?php if (isset($profileSuccess)): ?>
            <div class="success"><?php echo $profileSuccess; ?></div>
        <?php endif; ?>

        <!-- Follow button -->
        <button id="follow-button" data-action="<?php echo $follow_status ? 'unfollow' : 'follow'; ?>"><?php echo $follow_status ? 'Unfollow' : 'Follow'; ?></button>

        <button onclick="window.location.href='dashboard.php'">Back to dashboard</button>
        <br><br>
        <button onclick="window.location.href='profile_form.php'">Edit profile</button>
    <div>
        <?php echo htmlspecialchars($user['full_name']); ?>
    </div>
    <div>
        <?php echo htmlspecialchars($user['address']); ?>
    </div>
    <div>
        <?php echo htmlspecialchars($user['department']); ?>
    </div>

    <div>
        <?php echo htmlspecialchars($user['level']); ?>
    </div>

    <div>
        <?php echo htmlspecialchars($user['id_number']); ?>
        </div>

        <div>
        <?php echo htmlspecialchars($user['gender']); ?>
    </div>

    <div>
        <?php echo htmlspecialchars($user['about_me']); ?>
    </div>
    <div>
        <?php echo htmlspecialchars($user['interests']); ?>
    </div>
    <div>
        <?php echo htmlspecialchars($user['relationship_status']); ?>
    </div>
    <div>
        <?php echo htmlspecialchars($user['phone_number']); ?>
    </div>
    </div>

    <script>
        document.getElementById('follow-button').addEventListener('click', function() {
            var action = this.getAttribute('data-action');
            
            var xhr = new XMLHttpRequest();
            xhr.open('POST', 'profile.php', true);
            xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
            xhr.onreadystatechange = function() {
                if (xhr.readyState == 4 && xhr.status == 200) {
                    var response = JSON.parse(xhr.responseText);
                    if (response.status === 'success') {
                        document.getElementById('followers-count').textContent = response.followers_count;
                        document.getElementById('follow-button').textContent = response.button_text;
                        document.getElementById('follow-button').setAttribute('data-action', response.button_text.toLowerCase());
                    } else {
                        alert('Error updating follow status');
                    }
                }
            };
            xhr.send('follow=1&follow_action=' + action);
        });
    </script>
    
</body>
</html>
