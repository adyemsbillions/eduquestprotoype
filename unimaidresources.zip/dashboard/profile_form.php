<?php
// Include the database connection
include("db_connection.php");

// Start session to get user_id
session_start();

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    // Redirect to login if not logged in
    header("Location: login.php");
    exit();
}

// Get the logged-in user's ID
$user_id = $_SESSION['user_id'];

// Fetch the user profile information from the database
$sql = "SELECT * FROM users WHERE id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $user_id);  // Bind the user_id parameter
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    // Fetch the user's details
    $user = $result->fetch_assoc();
} else {
    // Handle the case where the user is not found in the database
    echo "User not found.";
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Profile</title>
    <style>
        /* Your styles for the page */
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f7f6;
            color: #333;
            margin: 0;
            padding: 0;
        }

        .container {
            width: 80%;
            margin: 0 auto;
            max-width: 900px;
            background-color: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            margin-top: 40px;
        }

        h1 {
            text-align: center;
            color: #333;
            margin-bottom: 20px;
        }

        label {
            font-size: 16px;
            font-weight: 500;
            margin-bottom: 8px;
            display: block;
        }

        input[type="text"], textarea, select {
            width: 100%;
            padding: 10px;
            margin-bottom: 20px;
            border: 1px solid #ddd;
            border-radius: 4px;
            font-size: 14px;
            box-sizing: border-box;
        }

        textarea {
            resize: vertical;
            height: 100px;
        }

        button[type="submit"] {
            background-color: purple;
            color: white;
            border: none;
            padding: 10px 20px;
            font-size: 16px;
            cursor: pointer;
            border-radius: 4px;
            transition: background-color 0.3s ease;
        }

        button[type="submit"]:hover {
            background-color: purple;
        }

        .form-group {
            margin-bottom: 20px;
        }

        .form-footer {
            text-align: center;
        }

        .form-footer a {
            color: #4CAF50;
            text-decoration: none;
        }

        .form-footer a:hover {
            text-decoration: underline;
        }

    </style>
</head>
<body>

    <div class="container">
        <h1>Edit Your Profile</h1>
        
        <!-- Profile Form -->
        <form action="update_profile.php" method="POST">

            <div class="form-group">
                <label for="full_name">Full Name:</label>
                <input type="text" name="full_name" value="<?php echo htmlspecialchars($user['full_name']); ?>" required>
            </div>

            <div class="form-group">
                <label for="address">Address:</label>
                <input type="text" name="address" value="<?php echo htmlspecialchars($user['address']); ?>">
            </div>

            <div class="form-group">
                <label for="department">Department:</label>
                <input type="text" name="department" value="<?php echo htmlspecialchars($user['department']); ?>">
            </div>

            <div class="form-group">
                <label for="faculty">Faculty:</label>
                <input type="text" name="faculty" value="<?php echo htmlspecialchars($user['faculty']); ?>">
            </div>

            <div class="form-group">
                <label for="level">Level:</label>
                <input type="text" name="level" value="<?php echo htmlspecialchars($user['level']); ?>">
            </div>

            <div class="form-group">
                <label for="id_number">ID Number:</label>
                <input type="text" name="id_number" value="<?php echo htmlspecialchars($user['id_number']); ?>">
            </div>

            <div class="form-group">
                <label for="phone_number">Phone Number:</label>
                <input type="text" name="phone_number" value="<?php echo htmlspecialchars($user['phone_number']); ?>">
            </div>

            <!-- Gender Field -->
            <div class="form-group">
                <label for="gender">Gender:</label>
                <select name="gender">
                    <option value="Male" <?php echo $user['gender'] == 'Male' ? 'selected' : ''; ?>>Male</option>
                    <option value="Female" <?php echo $user['gender'] == 'Female' ? 'selected' : ''; ?>>Female</option>

                </select>
            </div>

            <div class="form-group">
                <label for="stays_in_hostel">Do you stay in the hostel?</label>
                <select name="stays_in_hostel">
                    <option value="Yes" <?php echo $user['stays_in_hostel'] == 'Yes' ? 'selected' : ''; ?>>Yes</option>
                    <option value="No" <?php echo $user['stays_in_hostel'] == 'No' ? 'selected' : ''; ?>>No</option>
                </select>
            </div>

            <div class="form-group">
                <label for="about_me">About Me:</label>
                <textarea name="about_me"><?php echo htmlspecialchars($user['about_me']); ?></textarea>
            </div>

            <div class="form-group">
                <label for="interests">Interests:</label>
                <textarea name="interests"><?php echo htmlspecialchars($user['interests']); ?></textarea>
            </div>

            <div class="form-group">
                <label for="relationship_status">Relationship Status:</label>
                <select name="relationship_status">
                    <option value="Single" <?php echo $user['relationship_status'] == 'Single' ? 'selected' : ''; ?>>Single</option>
                    <option value="Married" <?php echo $user['relationship_status'] == 'Married' ? 'selected' : ''; ?>>Married</option>
                    <option value="In a relationship" <?php echo $user['relationship_status'] == 'In a relationship' ? 'selected' : ''; ?>>In a relationship</option>
                    <option value="It's complicated" <?php echo $user['relationship_status'] == 'It\'s complicated' ? 'selected' : ''; ?>>It's complicated</option>
                    <option value="Divorced" <?php echo $user['relationship_status'] == 'Divorced' ? 'selected' : ''; ?>>Divorced</option>
                    <option value="Widowed" <?php echo $user['relationship_status'] == 'Widowed' ? 'selected' : ''; ?>>Widowed</option>
                </select>
            </div>

            <button type="submit" name="update_profile">Update Profile</button>
        </form>

        <div class="form-footer">
            <p><a href="dashboard.php">Back to Dashboard</a></p>
        </div>
    </div>

</body>
</html>
