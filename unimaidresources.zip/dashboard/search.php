<?php
// Include the database connection
include("db_connection.php");

// Start session to handle logged-in user
session_start();

// Ensure the user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php"); // Redirect to login page if not logged in
    exit();
}

$user_id = $_SESSION['user_id'];  // Logged-in user ID
$search_query = isset($_GET['query']) ? $_GET['query'] : ''; // Get the search query from GET

// Handle Like Request
if (isset($_POST['like_post'])) {
    $post_id = $_POST['post_id'];

    // Check if the user has already liked the post
    $sql_check_like = "SELECT COUNT(*) AS like_count FROM post_likes WHERE post_id = ? AND user_id = ?";
    $stmt_check_like = $conn->prepare($sql_check_like);
    $stmt_check_like->bind_param("ii", $post_id, $user_id);
    $stmt_check_like->execute();
    $result_check_like = $stmt_check_like->get_result();
    $like_exists = $result_check_like->fetch_assoc()['like_count'];

    // If the user hasn't liked the post yet, insert the like
    if ($like_exists == 0) {
        $sql_insert_like = "INSERT INTO post_likes (post_id, user_id) VALUES (?, ?)";
        $stmt_insert_like = $conn->prepare($sql_insert_like);
        $stmt_insert_like->bind_param("ii", $post_id, $user_id);
        $stmt_insert_like->execute();
    }
    
    // Fetch the updated like count
    $sql_like_count = "SELECT COUNT(*) AS like_count FROM post_likes WHERE post_id = ?";
    $stmt_like_count = $conn->prepare($sql_like_count);
    $stmt_like_count->bind_param("i", $post_id);
    $stmt_like_count->execute();
    $result_like_count = $stmt_like_count->get_result();
    $like_count = $result_like_count->fetch_assoc()['like_count'];

    // Return the new like count in JSON format
    echo json_encode(['like_count' => $like_count]);
    exit(); // Finish the script to prevent further processing
}

// Fetch posts based on the search query
if (!empty($search_query)) {
    $sql = "SELECT p.*, u.username, u.profile_picture 
            FROM posts p
            JOIN users u ON p.user_id = u.id
            WHERE p.post_content LIKE ? OR u.username LIKE ?  -- Filter by both post content and username
            ORDER BY p.created_at DESC";
    
    $stmt = $conn->prepare($sql);
    $search_term = '%' . $search_query . '%'; // Search term with wildcards
    $stmt->bind_param("ss", $search_term, $search_term); // Bind both fields to the query
    $stmt->execute();
    $result = $stmt->get_result();
} else {
    // Fetch all posts if no search query
    $sql = "SELECT p.*, u.username, u.profile_picture 
            FROM posts p
            JOIN users u ON p.user_id = u.id
            ORDER BY p.created_at DESC";
    
    $stmt = $conn->prepare($sql);
    $stmt->execute();
    $result = $stmt->get_result();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>
    <style>
        /* Add your styles here */
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }
        .container {
            max-width: 900px;
            margin: 0 auto;
            padding: 20px;
        }
        .search-form {
            margin-bottom: 20px;
        }
        .post-card {
            background-color: #fff;
            margin: 10px 0;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
        }
        .post-header {
            display: flex;
            align-items: center;
            margin-bottom: 15px;
        }
        .post-header img {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            margin-right: 10px;
        }
        .post-header h3 {
            margin: 0;
            font-size: 18px;
        }
        .post-header p {
            font-size: 14px;
            color: #888;
            margin: 0;
        }
        .post-content {
            font-size: 16px;
            line-height: 1.6;
            margin-bottom: 15px;
        }
        .post-actions {
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .like-button {
            background-color: #6a1b9a;
            color: white;
            padding: 10px 15px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }
        .like-button.liked {
            background-color: #8e24aa;
        }
        .comments-section {
            margin-top: 20px;
        }
        .comments-section h4 {
            margin: 0;
            font-size: 18px;
        }
        /* Search Input Styles */
.search-form {
    margin: 20px 0;
    display: flex;
    justify-content: center;
}

.input-area {
    display: flex;
    align-items: center;
    position: relative;
    width: 100%;
    max-width: 500px; /* Max width for the search bar */
    background-color: #fff;
    border-radius: 25px;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
    padding: 8px 15px;
}

.input-area input {
    width: 100%;
    padding: 10px 15px;
    font-size: 16px;
    border: none;
    border-radius: 25px;
    outline: none;
    background-color: #f4f4f4;
    color: #333;
    transition: background-color 0.3s ease;
}

.input-area input:focus {
    background-color: #e8e8e8;
}

.input-area .mat-icon {
    font-size: 20px;
    color: #6a1b9a;
    margin-right: 10px;
}

.search-button {
    position: absolute;
    right: 10px;
    background-color: #6a1b9a;
    color: #fff;
    border: none;
    padding: 8px 12px;
    border-radius: 20px;
    cursor: pointer;
    font-size: 16px;
    outline: none;
    transition: background-color 0.3s ease;
}

.search-button:hover {
    background-color: #8e24aa;
}

/* Focus effect on the button */
.search-button:focus {
    box-shadow: 0 0 5px rgba(0, 0, 0, 0.2);
}
/* Limit image size within post media */
.post-media img {
    max-width: 100%;  /* Ensure image does not overflow its container */
    height: auto;     /* Maintain aspect ratio */
    border-radius: 10px;  /* Optional: add rounded corners */
    object-fit: cover;    /* Optional: ensure image fills space appropriately */
}

/* Limit video size within post media */
.post-media video {
    max-width: 100%;  /* Ensure video does not overflow */
    height: auto;     /* Maintain aspect ratio */
    border-radius: 10px;  /* Optional: add rounded corners */
}

    </style>
</head>
<body>

    <div class="container">
        <!-- Search Form -->
        <div class="search-form">
            <form  class="input-area d-flex align-items-center" action="search.php" method="GET">
                <input type="text" id="search-input" placeholder="your search" autocomplete="off" value="<?php echo htmlspecialchars($search_query); ?>">
                <!-- <button type="submit" class="search-button">Search</button> -->
            </form>
        </div>

        <!-- Search Results Container -->
        <div id="search-results">
            <?php if ($result->num_rows > 0): ?>
                <?php while ($post = $result->fetch_assoc()): ?>
                    <div class="post-card" id="post-<?php echo $post['post_id']; ?>">
                        <div class="post-header">
                            <img src="/unimaidconnect/dashboard/<?php echo htmlspecialchars($post['profile_picture']); ?>" alt="avatar">
                            <div>
                                <h3><?php echo htmlspecialchars($post['username']); ?></h3>
                                <p><?php echo date('F j, Y, g:i a', strtotime($post['created_at'])); ?></p>
                            </div>
                        </div>

                        <div class="post-content">
                            <p><?php echo nl2br(htmlspecialchars($post['post_content'])); ?></p>
                        </div>

                        <?php if ($post['media_type'] !== 'none'): ?>
                            <div class="post-media">
                                <?php if ($post['media_type'] === 'image'): ?>
                                    <img src="<?php echo htmlspecialchars($post['media_url']); ?>" alt="Post Image">
                                <?php elseif ($post['media_type'] === 'video'): ?>
                                    <video controls>
                                        <source src="<?php echo htmlspecialchars($post['media_url']); ?>" type="video/mp4">
                                        Your browser does not support the video tag.
                                    </video>
                                <?php endif; ?>
                            </div>
                        <?php endif; ?>

                        <?php
                        // Fetch the like count for this post
                        $sql_like_count = "SELECT COUNT(*) AS like_count FROM post_likes WHERE post_id = ?";
                        $stmt_like_count = $conn->prepare($sql_like_count);
                        $stmt_like_count->bind_param("i", $post['post_id']);
                        $stmt_like_count->execute();
                        $result_like_count = $stmt_like_count->get_result();
                        $like_count = $result_like_count->fetch_assoc()['like_count'];
                        ?>

                        <div class="post-actions">
                            <button class="like-button" id="like-btn-<?php echo $post['post_id']; ?>" data-post-id="<?php echo $post['post_id']; ?>">Like</button>
                            <p class="like-count" id="like-count-<?php echo $post['post_id']; ?>"><?php echo $like_count; ?> Likes</p>
                        </div>

                        <!-- Comments Section -->
                        <div class="comments-section">
                            <h4>Comments:</h4>
                            <!-- Comments will be displayed here -->
                        </div>
                    </div>
                <?php endwhile; ?>
            <?php else: ?>
                <p>No posts found for your search query.</p>
            <?php endif; ?>
        </div>
    </div>

    <script>
        // Handle Like Button Click
        document.querySelectorAll('.like-button').forEach(button => {
            button.addEventListener('click', function() {
                const postId = this.getAttribute('data-post-id');

                fetch('search.php', {
                    method: 'POST',
                    body: new URLSearchParams({
                        like_post: true,
                        post_id: postId
                    })
                })
                .then(response => response.json())
                .then(data => {
                    // Update the like count dynamically
                    document.getElementById('like-count-' + postId).textContent = data.like_count + ' Likes';
                    document.getElementById('like-btn-' + postId).classList.add('liked');
                });
            });
        });
    </script>

</body>
</html>
