<?php
include 'db_connection.php';
session_start();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $club = $_POST['club'];
    $username = $_SESSION['username']; // Assuming username is set in session

    // Save club to the users table
    $stmt = $conn->prepare("UPDATE users SET club = ?, first_time = 0 WHERE username = ?");
    $stmt->execute([$club, $username]);

    $_SESSION['first_time'] = false;  // Mark as not first time anymore
    header("Location: football.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Select Your Club</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="container">
        <h1>Welcome! Select Your Football Club</h1>
        <form method="POST">
            <select name="club" required>
                <option value="">Choose your club</option>
                <option value="Manchester United">Manchester United</option>
                <option value="Real Madrid">Real Madrid</option>
                <option value="Barcelona">Barcelona</option>
                <option value="Liverpool">Liverpool</option>
                <option value="Chelsea">Chelsea</option>
                <!-- Add more clubs as needed -->
            </select>
            <button type="submit">Submit</button>
        </form>
    </div>
</body>
</html>
