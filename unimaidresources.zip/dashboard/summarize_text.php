<?php
// Function to summarize text by extracting key points
function summarizeText($text) {
    // Simple method: split text into sentences, pick first few sentences as the "summary"
    $sentences = explode('.', $text);
    
    // We will take the first 3 sentences as the summary
    $summary = array_slice($sentences, 0, 3);
    
    // Join them back into a string
    return implode('. ', $summary) . '.';
}

// Initialize the summarized text
$summary = '';

// Process form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['text'])) {
    $input_text = $_POST['text'];
    $summary = summarizeText($input_text);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Text Summarizer</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }

        .container {
            width: 90%;
            max-width: 800px;
            padding: 20px;
            background-color: white;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        h1 {
            text-align: center;
            color: #333;
        }

        textarea {
            width: 100%;
            height: 200px;
            padding: 12px;
            font-size: 16px;
            border: 1px solid #ccc;
            border-radius: 6px;
            margin-top: 10px;
            margin-bottom: 20px;
            resize: none;
            box-sizing: border-box;
        }

        button {
            background-color: purple;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 6px;
            cursor: pointer;
            font-size: 16px;
            transition: background-color 0.3s;
            width: 100%;
        }

        button:hover {
            background-color: #218838;
        }

        .summary-section {
            margin-top: 30px;
        }

        .summary-title {
            font-size: 20px;
            font-weight: bold;
            color: #333;
            margin-bottom: 10px;
        }

        .summary-text {
            background-color: #f9f9f9;
            padding: 20px;
            border-radius: 6px;
            border: 1px solid #ddd;
            font-size: 16px;
            color: #555;
        }

        @media (max-width: 600px) {
            .container {
                padding: 15px;
            }

            textarea {
                height: 150px;
                font-size: 14px;
            }
        }
    </style>
</head>
<body>

<div class="container">
    <h1>Handout Summarizer</h1>
    <form method="POST">
        <textarea name="text" placeholder="Paste your text here..." required><?php echo isset($input_text) ? htmlspecialchars($input_text) : ''; ?></textarea>
        <button type="submit">Summarize</button>
    </form>

    <?php if ($summary): ?>
        <div class="summary-section">
            <div class="summary-title">Summary:</div>
            <div class="summary-text"><?php echo htmlspecialchars($summary); ?></div>
        </div>
    <?php endif; ?>
</div>

</body>
</html>
