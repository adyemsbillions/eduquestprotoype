<?php 
// Include the database connection 
include("db_connection.php");  

// Start session 
session_start();  

// Check if user is logged in 
if (!isset($_SESSION['user_id'])) {     
    // Redirect to login if not logged in     
    header("Location: login.php");     
    exit(); 
}  

// Get user_id from session 
$user_id = $_SESSION['user_id'];  

// Check if the form was submitted 
if (isset($_POST['update_profile'])) {     
    // Collect form data     
    $full_name = $_POST['full_name'];     
    $address = $_POST['address'];     
    $department = $_POST['department'];     
    $faculty = $_POST['faculty'];     
    $level = $_POST['level'];     
    $id_number = $_POST['id_number'];     
    $phone_number = $_POST['phone_number'];     
    $gender = $_POST['gender'];     
    $stays_in_hostel = $_POST['stays_in_hostel'];     
    $about_me = $_POST['about_me'];     
    $interests = $_POST['interests'];     
    $relationship_status = $_POST['relationship_status'];     

    // Prepare the SQL update query (no profile picture update)     
    $sql = "UPDATE users SET              
                full_name = ?,              
                address = ?,              
                department = ?,              
                faculty = ?,              
                level = ?,              
                id_number = ?,              
                phone_number = ?,              
                gender = ?,              
                stays_in_hostel = ?,              
                about_me = ?,              
                interests = ?,              
                relationship_status = ?              
                WHERE id = ?";  

    // Prepare the statement     
    $stmt = $conn->prepare($sql);     
    $stmt->bind_param("ssssssssssssi", $full_name, $address, $department, $faculty, $level, $id_number, $phone_number, $gender, $stays_in_hostel, $about_me, $interests, $relationship_status, $user_id);  

    // Execute the query     
    if ($stmt->execute()) {         
        // Redirect to the profile page after successful update         
        header("Location: profile.php");         
        exit();     
    } else {         
        echo "Error updating profile: " . $stmt->error;     
    } 
} 
?>
