<?php
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    include('db_connection.php');

    $title = $_POST['title'];
    $category = $_POST['category'];
    $download_link = $_POST['download_link'];
    $note = $_POST['note'];
    $image = $_FILES['image']['name'];

    // Handle Google Drive link conversion
    if (strpos($download_link, 'drive.google.com') !== false) {
        // Extract file ID from the Google Drive link
        preg_match('/\/d\/(.*?)(\/|%2F|$)/', $download_link, $matches);
        $file_id = $matches[1];
        
        // Create a direct download link
        $download_link = "https://drive.google.com/uc?export=download&id=" . $file_id;
    }

    // Handle file upload
    $target_dir = "uploads/";
    $target_file = $target_dir . basename($image);
    move_uploaded_file($_FILES["image"]["tmp_name"], $target_file);

    // Insert data into the respective table based on category
    $stmt = $conn->prepare("INSERT INTO $category (title, image, download_link, note, category) VALUES (?, ?, ?, ?, ?)");
    $stmt->bind_param("sssss", $title, $target_file, $download_link, $note, $category);

    if ($stmt->execute()) {
        echo "New record created successfully";
    } else {
        echo "Error: " . $stmt->error;
    }
    $stmt->close();
    $conn->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Upload Handout</title>
    <style>
        /* General Styles */
        body {
            font-family: Arial, sans-serif;
            background-color: #f7f7f7;
            margin: 0;
            padding: 0;
        }

        .container {
            max-width: 900px;
            margin: 40px auto;
            padding: 30px;
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
        }

        h1 {
            text-align: center;
            color: #333;
            font-size: 28px;
            margin-bottom: 20px;
        }

        form {
            display: flex;
            flex-direction: column;
        }

        label {
            font-size: 16px;
            margin-bottom: 8px;
            color: #555;
        }

        input[type="text"],
        input[type="file"],
        input[type="url"],
        select,
        textarea {
            padding: 10px;
            margin-bottom: 20px;
            font-size: 16px;
            border-radius: 6px;
            border: 1px solid #ccc;
            background-color: #f9f9f9;
            box-sizing: border-box;
        }

        textarea {
            resize: vertical;
            min-height: 100px;
        }

        input[type="file"] {
            border: none;
            background-color: #fff;
        }

        input[type="file"]::file-selector-button {
            background-color: #007BFF;
            color: white;
            border: none;
            border-radius: 6px;
            padding: 10px 20px;
            font-size: 16px;
            cursor: pointer;
            box-sizing: border-box;
        }

        input[type="file"]::file-selector-button:hover {
            background-color: #0056b3;
        }

        select {
            cursor: pointer;
        }

        input[type="submit"] {
            background-color: #28a745;
            color: white;
            border: none;
            padding: 12px 20px;
            font-size: 16px;
            font-weight: bold;
            border-radius: 6px;
            cursor: pointer;
            transition: background-color 0.3s ease;
            margin-top: 20px;
        
        }

        input[type="submit"]:hover {
            background-color: #218838;
        }

        .form-group {
            margin-bottom: 20px;
        }

        .form-group input,
        .form-group select,
        .form-group textarea {
            width: 100%;
        }

        .form-group input[type="file"] {
            display: inline-block;
            width: auto;
        }

        /* Responsive Design */
        @media (max-width: 768px) {
            .container {
                margin: 20px;
                padding: 15px;
            }

            h1 {
                font-size: 24px;
            }

            input[type="submit"] {
                width: 100%;
            }
        }
    </style>
</head>
<body>

<div class="container">
    <h1>Upload Handout</h1>
    <form action="upload_handout.php" method="POST" enctype="multipart/form-data">
        <div class="form-group">
            <label for="title">Title:</label>
            <input type="text" name="title" required>
        </div>

        <div class="form-group">
            <label for="image">Upload Image:</label>
            <input type="file" name="image" required>
        </div>

        <div class="form-group">
            <label for="download_link">Download Link (Google Drive link):</label>
            <input type="url" name="download_link" required>
        </div>

        <div class="form-group">
            <label for="category">Category:</label>
            <select name="category">
                <option value="handouts">Handouts</option>
                <option value="past_questions">Past Questions</option>
                <option value="summaries">Summaries</option>
            </select>
        </div>

        <div class="form-group">
            <label for="note">Optional Note:</label>
            <textarea name="note"></textarea>
        </div>

        <input type="submit" value="Upload">
    </form>
</div>

</body>
</html>
