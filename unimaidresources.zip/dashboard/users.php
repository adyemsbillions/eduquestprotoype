<?php
// Database connection
$conn = new mysqli("localhost", "root", "", "UNIMAIDCONNECT");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Start session and get the logged-in user's ID
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php"); // Redirect to login if not logged in
    exit();
}

$user_id = $_SESSION['user_id'];

// Get all users except the logged-in user
$sql_users = "SELECT id, username, profile_picture FROM users WHERE id != ?";
$stmt_users = $conn->prepare($sql_users);
$stmt_users->bind_param("i", $user_id);
$stmt_users->execute();
$users_result = $stmt_users->get_result();

// Get the follow status for each user
$follow_status = [];
$sql_follow_status = "SELECT following_id FROM followers WHERE follower_id = ?";
$stmt_follow_status = $conn->prepare($sql_follow_status);
$stmt_follow_status->bind_param("i", $user_id);
$stmt_follow_status->execute();
$follow_status_result = $stmt_follow_status->get_result();

// Store the followed users in an array for easy access
while ($row = $follow_status_result->fetch_assoc()) {
    $follow_status[$row['following_id']] = true;
}

// Get the follower count for each user
$follower_counts = [];
$sql_follower_counts = "SELECT following_id, COUNT(*) AS followers FROM followers GROUP BY following_id";
$stmt_follower_counts = $conn->prepare($sql_follower_counts);
$stmt_follower_counts->execute();
$result_follower_counts = $stmt_follower_counts->get_result();

// Store follower count in an array for easy access
while ($row = $result_follower_counts->fetch_assoc()) {
    $follower_counts[$row['following_id']] = $row['followers'];
}

// Handle Follow/Unfollow action via AJAX
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['follow'])) {
    $user_id_to_follow = $_POST['user_id'];
    $action = $_POST['follow_action']; // Either "follow" or "unfollow"

    if ($action === 'follow') {
        // Follow the user
        $sql_follow = "INSERT INTO followers (follower_id, following_id) VALUES (?, ?)";
        $stmt_follow = $conn->prepare($sql_follow);
        $stmt_follow->bind_param("ii", $user_id, $user_id_to_follow);
        if ($stmt_follow->execute()) {
            // Get updated follower count for the followed user
            $sql_followers = "SELECT COUNT(*) AS followers FROM followers WHERE following_id = ?";
            $stmt_followers = $conn->prepare($sql_followers);
            $stmt_followers->bind_param("i", $user_id_to_follow);
            $stmt_followers->execute();
            $followers_result = $stmt_followers->get_result();
            $followers_count = $followers_result->fetch_assoc()['followers'];

            // Return updated count and button text
            echo json_encode(['status' => 'success', 'followers_count' => $followers_count, 'button_text' => 'Unfollow']);
        } else {
            echo json_encode(['status' => 'error']);
        }
    } elseif ($action === 'unfollow') {
        // Unfollow the user
        $sql_unfollow = "DELETE FROM followers WHERE follower_id = ? AND following_id = ?";
        $stmt_unfollow = $conn->prepare($sql_unfollow);
        $stmt_unfollow->bind_param("ii", $user_id, $user_id_to_follow);
        if ($stmt_unfollow->execute()) {
            // Get updated follower count for the followed user
            $sql_followers = "SELECT COUNT(*) AS followers FROM followers WHERE following_id = ?";
            $stmt_followers = $conn->prepare($sql_followers);
            $stmt_followers->bind_param("i", $user_id_to_follow);
            $stmt_followers->execute();
            $followers_result = $stmt_followers->get_result();
            $followers_count = $followers_result->fetch_assoc()['followers'];

            // Return updated count and button text
            echo json_encode(['status' => 'success', 'followers_count' => $followers_count, 'button_text' => 'Follow']);
        } else {
            echo json_encode(['status' => 'error']);
        }
    }
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>All Users</title>
    <style>
   
        body {
            background-color: #f9f9f9;
            color: #333;
            font-family: Arial, sans-serif;
        }

        .container {
            max-width: 900px;
            margin: 0 auto;
            background-color: #fff;
            padding: 30px;
            border-radius: 8px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }

        h2 {
            text-align: center;
            margin-bottom: 20px;
        }

        .user-card {
            display: flex;
            align-items: center;
            margin-bottom: 20px;
            border-bottom: 1px solid #ddd;
            padding-bottom: 10px;
        }

        .user-card img {
            width: 60px;
            height: 60px;
            object-fit: cover;
            border-radius: 50%;
            margin-right: 15px;
        }

        .user-card .user-info {
            flex-grow: 1;
        }

        .user-card button {
            background-color: #6a1b9a;
            color: white;
            padding: 8px 15px;
            font-size: 14px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }

        .user-card button:hover {
            background-color: #8e24aa;
        }

        .followers-count {
            font-size: 12px;
            margin-top: 5px;
            color: black;
            font-weight: bolder;
        }

        .user-list {
            margin-top: 20px;
        }

        .message-icon {
            cursor: pointer;
            margin-left: 10px;
            font-size: 18px;
            color: #6a1b9a;
        }

        .message-icon:hover {
            color: #8e24aa;
        }
  
    </style>
</head>
<body>
    <div class="container">
        <h2>All Students</h2>
        
        <div class="user-list">
            <?php
            // Sort users by follower count (most followed first)
            $users = [];
            while ($user = $users_result->fetch_assoc()) {
                $user['followers_count'] = isset($follower_counts[$user['id']]) ? $follower_counts[$user['id']] : 0;
                $users[] = $user;
            }

            usort($users, function($a, $b) {
                return $b['followers_count'] - $a['followers_count'];
            });

            foreach ($users as $user): ?>
                <div class="user-card">
                    <!-- User Profile Picture -->
                    <img src="/unimaidconnect/dashboard/<?php echo htmlspecialchars($user['profile_picture']); ?>" alt="Profile Image">
                    
                    <div class="user-info">
                        <!-- Username -->
                        <a href="view_profile.php?user_id=<?php echo $user['id']; ?>"><?php echo htmlspecialchars($user['username']); ?></a>

                        <!-- Follower Count -->
     <b>                   <h3 class="followers-count" id="followers-count-<?php echo $user['id']; ?>">Followers: <?php echo $user['followers_count']; ?></h3></b>
                    </div>

                    <!-- Follow/Unfollow Button -->
                    <button class="follow-button" data-user-id="<?php echo $user['id']; ?>">
                        <?php echo isset($follow_status[$user['id']]) ? 'Unfollow' : 'Follow'; ?>
                    </button>

                    <!-- Message Icon -->
                
                </div>
            <?php endforeach; ?>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script>
        $(document).ready(function() {
            // Follow/Unfollow Action
            $('.follow-button').click(function() {
                var userId = $(this).data('user-id');
                var button = $(this);

                var action = button.text() === 'Follow' ? 'follow' : 'unfollow';

                $.post('users.php', {
                    follow: 1,
                    user_id: userId,
                    follow_action: action
                }, function(response) {
                    response = JSON.parse(response);
                    if (response.status === 'success') {
                        button.text(response.button_text);
                        $('#followers-count-' + userId).text('Followers: ' + response.followers_count);
                    }
                });
            });
        });
    </script>
</body>
</html>
