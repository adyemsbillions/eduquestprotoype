<?php
include("db_connection.php");

// Start session to handle logged-in user
session_start();

// Assume user is logged in, and their user_id is stored in session
if (!isset($_SESSION['user_id'])) {
    // Redirect to login page if not logged in
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id']; // Logged-in user ID

// Check if reply form is submitted
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['reply_text'])) {
    // Get the form data
    $post_id = $_POST['post_id'];
    $comment_id = $_POST['comment_id'];
    $reply_text = $_POST['reply_text'];

    // Validate the post_id, comment_id, and reply_text
    if (!$post_id || !$comment_id || empty($reply_text)) {
        echo json_encode(["status" => "error", "message" => "Missing required data"]);
        exit();
    }

    // Insert the reply into the database
    $sql_insert_reply = "INSERT INTO replies (comment_id, post_id, user_id, reply_text, created_at) 
                         VALUES (?, ?, ?, ?, NOW())";
    $stmt = $conn->prepare($sql_insert_reply);
    $stmt->bind_param("iiis", $comment_id, $post_id, $user_id, $reply_text);

    if ($stmt->execute()) {
        // Get the new reply data
        $reply_id = $stmt->insert_id;
        $sql_get_reply = "SELECT r.reply_text, u.username, r.created_at
                          FROM replies r
                          JOIN users u ON r.user_id = u.id
                          WHERE r.reply_id = ?";
        $stmt_reply = $conn->prepare($sql_get_reply);
        $stmt_reply->bind_param("i", $reply_id);
        $stmt_reply->execute();
        $result_reply = $stmt_reply->get_result();
        $reply = $result_reply->fetch_assoc();

        // Send back the new reply in JSON format
        echo json_encode([
            "status" => "success",
            "reply_html" => '
                <div class="reply">
                    <strong>' . htmlspecialchars($reply['username']) . ' replied:</strong>
                    <p>' . nl2br(htmlspecialchars($reply['reply_text'])) . '</p>
                    <p><small>' . date('F j, Y, g:i a', strtotime($reply['created_at'])) . '</small></p>
                </div>'
        ]);
        exit();
    } else {
        echo json_encode(["status" => "error", "message" => "Unable to submit reply"]);
    }
}

// Check if post_id is set and valid
if (isset($_GET['post_id']) && is_numeric($_GET['post_id'])) {
    $post_id = $_GET['post_id'];

    // Fetch the post data using post_id
    $sql_post = "SELECT p.post_content, p.created_at, u.username, p.media_url, p.media_type
                 FROM posts p
                 JOIN users u ON p.user_id = u.id 
                 WHERE p.post_id = ?";
    $stmt = $conn->prepare($sql_post);
    $stmt->bind_param("i", $post_id);
    $stmt->execute();
    $result_post = $stmt->get_result();

    if ($result_post->num_rows > 0) {
        $post = $result_post->fetch_assoc();
    } else {
        echo "No post found for the given post_id.";
        exit;
    }

    // Fetch the comments for this post (most recent first)
    $sql_comments = "SELECT c.comment_id, c.comment_text, u.username, c.created_at
                     FROM comments c
                     JOIN users u ON c.user_id = u.id
                     WHERE c.post_id = ? ORDER BY c.created_at DESC";
    $stmt_comments = $conn->prepare($sql_comments);
    $stmt_comments->bind_param("i", $post_id);
    $stmt_comments->execute();
    $result_comments = $stmt_comments->get_result();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Post Comments</title>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <style>
        /* Add necessary CSS styles for the reply section */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: Arial, sans-serif;
        }
        body {
            background-color: #f9f9f9;
            color: #333;
            line-height: 1.6;
            font-size: 16px;
            padding: 20px;
        }
        .container {
            max-width: 1200px;
            margin: 0 auto;
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            padding: 20px;
        }
        h2 {
            font-size: 24px;
            color: #6a1b9a;
            margin-bottom: 15px;
        }
        .post-content {
            font-size: 18px;
            color: #333;
            margin-bottom: 20px;
            padding: 15px;
            background-color: #f1f1f1;
            border-radius: 8px;
        }
        .comment {
            margin-bottom: 20px;
            padding: 15px;
            background-color: #fafafa;
            border-left: 5px solid #6a1b9a;
            border-radius: 8px;
        }
        .comment strong {
            color: #6a1b9a;
            font-size: 16px;
        }
        .reply {
            background-color: #f9f9f9;
            padding: 10px;
            margin-bottom: 10px;
            border-left: 3px solid #6a1b9a;
            border-radius: 6px;
        }
        .reply strong {
            color: #6a1b9a;
            font-size: 14px;
        }
        .reply p {
            color: #444;
            font-size: 14px;
        }
        .reply-time {
            font-size: 12px;
            color: #888;
            margin-top: 5px;
        }
        textarea {
            width: 100%;
            padding: 10px;
            font-size: 14px;
            border: 1px solid #ccc;
            border-radius: 5px;
            background-color: #fafafa;
            resize: vertical;
        }
        button {
            padding: 10px 15px;
            background-color: #6a1b9a;
            color: #fff;
            font-size: 14px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            margin-top: 10px;
        }
        button:hover {
            background-color: #8e24aa;
        }
    </style>
</head>
<body>

<div class="container">
    <h2>Post by <?php echo htmlspecialchars($post['username']); ?></h2>
    <p class="post-content"><?php echo nl2br(htmlspecialchars($post['post_content'])); ?></p>
    <p><strong>Posted on: </strong><?php echo date('F j, Y, g:i a', strtotime($post['created_at'])); ?></p>

    <?php if (!empty($post['media_url'])): ?>
        <div class="post-media">
            <?php if ($post['media_type'] == 'image'): ?>
                <img src="<?php echo htmlspecialchars($post['media_url']); ?>" alt="Post Image">
            <?php elseif ($post['media_type'] == 'video'): ?>
                <video controls>
                    <source src="<?php echo htmlspecialchars($post['media_url']); ?>" type="video/mp4">
                    Your browser does not support the video tag.
                </video>
            <?php endif; ?>
        </div>
    <?php endif; ?>

    <h3>Comments</h3>
    <?php while ($comment = $result_comments->fetch_assoc()): ?>
        <div class="comment">
            <strong><?php echo htmlspecialchars($comment['username']); ?>:</strong>
            <p><?php echo nl2br(htmlspecialchars($comment['comment_text'])); ?></p>
            <p><small><?php echo date('F j, Y, g:i a', strtotime($comment['created_at'])); ?></small></p>

            <!-- Replies to the comment -->
            <div class="replies" id="replies-<?php echo $comment['comment_id']; ?>">
                <?php
                // Fetch replies for this comment
                $sql_replies = "SELECT r.reply_text, u.username, r.created_at
                                FROM replies r
                                JOIN users u ON r.user_id = u.id
                                WHERE r.comment_id = ? ORDER BY r.created_at DESC";
                $stmt_replies = $conn->prepare($sql_replies);
                $stmt_replies->bind_param("i", $comment['comment_id']);
                $stmt_replies->execute();
                $result_replies = $stmt_replies->get_result();

                while ($reply = $result_replies->fetch_assoc()): ?>
                    <div class="reply">
                        <strong><?php echo htmlspecialchars($reply['username']); ?> replied:</strong>
                        <p><?php echo nl2br(htmlspecialchars($reply['reply_text'])); ?></p>
                        <p><small><?php echo date('F j, Y, g:i a', strtotime($reply['created_at'])); ?></small></p>
                    </div>
                <?php endwhile; ?>
            </div>

            <!-- Reply Form -->
            <form method="POST" class="reply-form" data-comment-id="<?php echo $comment['comment_id']; ?>" data-post-id="<?php echo $post_id; ?>">
                <textarea name="reply_text" placeholder="Add a reply..." required></textarea>
                <button type="submit">Post Reply</button>
            </form>
        </div>
    <?php endwhile; ?>
</div>

<script>
$(document).ready(function() {
    // Handle reply form submission
    $(".reply-form").on("submit", function(e) {
        e.preventDefault();

        var commentId = $(this).data("comment-id");
        var postId = $(this).data("post-id");
        var replyText = $(this).find("textarea").val();

        if (replyText.trim() === "") return;

        var form = $(this);
        var button = form.find("button");
        button.prop("disabled", true); // Disable the button to prevent multiple submissions

        $.ajax({
            url: "", // Same file, since the logic is here
            type: "POST",
            data: {
                post_id: postId,
                comment_id: commentId,
                reply_text: replyText
            },
            dataType: "json",
            success: function(response) {
                if (response.status === "success") {
                    // Append the new reply to the replies section
                    $("#replies-" + commentId).append(response.reply_html);
                    form.find("textarea").val(""); // Clear the textarea
                } else {
                    alert(response.message); // Show error message if something went wrong
                }
                button.prop("disabled", false); // Re-enable the button
            },
            error: function() {
                alert("An error occurred while submitting the reply.");
                button.prop("disabled", false); // Re-enable the button on error
            }
        });
    });
});
</script>

</body>
</html>
