<?php
session_start(); // Start session

// Ensure user is logged in
if (!isset($_SESSION['user_id'])) {
    die("You need to log in first.");
}

$userId = $_SESSION['user_id']; // Get the logged-in user ID

// Database connection
$conn = new mysqli('localhost', 'root', '', 'unimaidconnect');

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch available public groups the user is not a member of yet
$sql = "SELECT g.id, g.name, g.description, g.is_public
        FROM groups g
        LEFT JOIN group_members gm ON g.id = gm.group_id AND gm.user_id = '$userId'
        WHERE (g.is_public = 1 OR gm.user_id IS NOT NULL)"; // Show public groups or groups user is a member of

$result = $conn->query($sql);

if ($result->num_rows > 0) {
    echo "<div class='container'>";
    echo "<h1>Available Groups</h1>";
    while ($row = $result->fetch_assoc()) {
        echo "<div class='group'>";
        echo "<h3>" . htmlspecialchars($row['name']) . "</h3>";
        echo "<p>" . htmlspecialchars($row['description']) . "</p>";
        
        // If the user is not a member, show a join button
        if (empty($row['user_id'])) {
            echo "<form action='join_group.php' method='POST'>
                    <input type='hidden' name='group_id' value='" . $row['id'] . "'>
                    <input type='submit' value='Join Group'>
                </form>";
        } else {
            echo "<p class='already-member'>You are already a member of this group.</p>";
        }
        
        echo "</div><hr>";
    }
    echo "</div>";
} else {
    echo "<p>No groups available to join.</p>";
}

$conn->close();
?>
<style>
/* General container */
body {
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    background-color: #e9ecef;
    color: #495057;
    margin: 0;
    padding: 0;
}

/* Main content area */
.container {
    width: 85%;
    max-width: 1200px;
    margin: 40px auto;
    padding: 30px;
    background-color: #fff;
    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
    border-radius: 10px;
}

/* Heading */
h1 {
    text-align: center;
    font-size: 36px;
    color: #343a40;
    margin-bottom: 20px;
}

/* Group section */
.group {
    background-color: #ffffff;
    border: 1px solid #e2e6ea;
    padding: 20px;
    margin-bottom: 20px;
    border-radius: 8px;
    box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.05);
    transition: box-shadow 0.3s ease;
}

.group:hover {
    box-shadow: 0px 6px 15px rgba(0, 0, 0, 0.1);
}

/* Group title */
.group h3 {
    margin: 0 0 10px 0;
    font-size: 28px;
    color: #007bff;
    font-weight: 600;
}

/* Group description */
.group p {
    font-size: 16px;
    color: #6c757d;
    line-height: 1.6;
}

/* Button styling */
.group form {
    margin-top: 15px;
    text-align: center;
}

.group input[type="submit"] {
    background-color: #28a745;
    color: white;
    border: none;
    padding: 12px 24px;
    border-radius: 5px;
    cursor: pointer;
    font-size: 16px;
    transition: background-color 0.3s ease, transform 0.2s ease;
}

.group input[type="submit"]:hover {
    background-color: #218838;
    transform: translateY(-2px);
}

.group input[type="submit"]:active {
    background-color: #1e7e34;
    transform: translateY(0);
}

/* Group member info */
.group .member-count {
    font-weight: 500;
    margin-top: 10px;
    font-size: 14px;
}

/* Group link styling */
.group a {
    text-decoration: none;
    color: #007bff;
    font-weight: bold;
    margin-top: 10px;
    display: inline-block;
}

.group a:hover {
    text-decoration: underline;
}

/* Separator */
hr {
    border: 0;
    border-top: 2px solid #dee2e6;
    margin: 30px 0;
}

/* Already a member message */
.group .already-member {
    font-size: 14px;
    color: #6c757d;
    font-style: italic;
    text-align: center;
}

/* Small screen styling */
@media (max-width: 768px) {
    .container {
        width: 85%;
        padding: 20px;
    }

    h1 {
        font-size: 30px;
    }

    .group h3 {
        font-size: 24px;
    }

    .group p {
        font-size: 14px;
    }

    .group input[type="submit"] {
        padding: 10px 20px;
        font-size: 14px;
    }
}
</style>
