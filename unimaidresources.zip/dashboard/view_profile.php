

<?php
// Database connection
$conn = new mysqli("localhost", "root", "", "UNIMAIDCONNECT");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Start session and get the logged-in user's ID
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php"); // Redirect to login if not logged in
    exit();
}

$user_id = $_SESSION['user_id'];

// Get the user_id from the URL parameter (the user whose profile we're viewing)
if (isset($_GET['user_id'])) {
    $view_user_id = $_GET['user_id'];

    // Fetch user profile details from the database
    $sql = "SELECT * FROM users WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $view_user_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $user = $result->fetch_assoc();

    // If user doesn't exist, redirect back to all users
    if (!$user) {
        header("Location: all_users.php");
        exit();
    }
} else {
    // Redirect back if no user_id is provided
    header("Location: all_users.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($user['username']); ?>'s Profile</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f9f9f9;
            color: #333;
        }

        .container {
            width: 80%;
            margin: 0 auto;
            padding: 20px;
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }

        h1 {
            text-align: center;
            margin-bottom: 30px;
        }

        .profile-header {
            display: flex;
            align-items: center;
            margin-bottom: 30px;
        }

        .profile-header img {
            width: 100px;
            height: 100px;
            object-fit: cover;
            border-radius: 50%;
            margin-right: 20px;
        }

        .profile-info {
            flex-grow: 1;
        }

        .profile-info h3 {
            margin: 0;
        }

        .profile-info p {
            font-size: 16px;
            color: #555;
        }

        .profile-info .followers-count {
            margin-top: 10px;
        }

        .profile-details {
            margin-top: 20px;
        }

        .profile-details div {
            margin-bottom: 10px;
        }

        .profile-details label {
            font-weight: bold;
            color: #555;
        }

        .back-button {
            display: inline-block;
            margin-top: 20px;
            padding: 10px 20px;
            background-color: #6a1b9a;
            color: white;
            text-decoration: none;
            border-radius: 5px;
        }

        .back-button:hover {
            background-color: #8e24aa;
        }
    </style>
</head>
<body>

<div class="container">
    <h1><?php echo htmlspecialchars($user['username']); ?>'s Profile</h1>
    
    <!-- Profile Header -->
    <div class="profile-header">
        <img src="/unimaidconnect/dashboard/<?php echo htmlspecialchars($user['profile_picture']); ?>" alt="Profile Picture">
        
        <div class="profile-info">
            <h3><?php echo htmlspecialchars($user['username']); ?></h3>
            <p><?php echo htmlspecialchars($user['full_name']); ?></p>
          
        </div>
    </div>

    <!-- Profile Details -->
    <div class="profile-details">
        <div>
            <label>Full Name:</label> <?php echo htmlspecialchars($user['full_name']); ?>
        </div>
        <div>
            <label>Address:</label> <?php echo htmlspecialchars($user['address']); ?>
        </div>
        <div>
            <label>Department:</label> <?php echo htmlspecialchars($user['department']); ?>
        </div>
        <div>
            <label>Faculty:</label> <?php echo htmlspecialchars($user['faculty']); ?>
        </div>
        <div>
            <label>Level:</label> <?php echo htmlspecialchars($user['level']); ?>
        </div>
       
        <div>
            <label>Phone Number:</label> <?php echo htmlspecialchars($user['phone_number']); ?>
        </div>
       
        <div>
            <label>About Me:</label> <?php echo nl2br(htmlspecialchars($user['about_me'])); ?>
        </div>
        <div>
            <label>Interests:</label> <?php echo nl2br(htmlspecialchars($user['interests'])); ?>
        </div>
        <div>
            <label>Relationship Status:</label> <?php echo htmlspecialchars($user['relationship_status']); ?>
        </div>
    </div>

    <!-- Back Button -->
    <a href="users.php" class="back-button">Back to Users List</a>
</div>

</body>
</html>
