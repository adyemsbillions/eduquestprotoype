<?php
session_start();
include 'db_connection.php';

// Fetch approved images ordered by highest votes first
$sql = "SELECT * FROM wcw_images WHERE approved = 1 ORDER BY votes DESC";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Vote for Your WCW</title>
    <style>
        /* General Body Styles */
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f4;
        }

        /* Container for all content */
        .container {
            width: 90%; /* Use 90% width for small screens */
            margin: auto;
            padding: 20px;
            box-sizing: border-box;
        }

        /* Title Styles */
        h2 {
            text-align: center;
            color: #333;
            margin-bottom: 20px;
        }

        /* Image Box Styles */
        .image-box {
            display: inline-block;
            width: 100%; /* Default to 100% for small screens */
            max-width: 250px; /* Maximum width for each box */
            margin: 10px;
            padding: 15px;
            background-color: #fff;
            box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.1);
            border-radius: 10px;
            text-align: center;
            transition: transform 0.3s ease;
        }

        .image-box:hover {
            transform: scale(1.05);
        }

        /* Image Styles */
        .wcw-image {
            width: 100%;
            height: auto;
            border-radius: 10px;
            box-shadow: 0px 2px 10px rgba(0, 0, 0, 0.1);
        }

        /* Name Styles */
        .name {
            font-size: 16px;
            font-weight: bold;
            margin-top: 10px;
            color: #333;
        }

        /* Votes Count */
        .votes {
            font-size: 14px;
            color: #777;
            margin-top: 5px;
        }

        /* Vote Button */
        .vote-button {
            display: inline-block;
            padding: 10px 20px;
            margin-top: 10px;
            background-color: purple;
            color: white;
            text-decoration: none;
            border-radius: 5px;
            font-weight: bold;
        }

        .vote-button:hover {
            background-color: #45a049;
        }

        /* Message Styles */
        .message {
            text-align: center;
            font-size: 18px;
            font-weight: bold;
            margin-bottom: 20px;
        }

        .success {
            color: green;
        }

        .error {
            color: red;
        }

        /* Mobile Responsive Design */
        @media (max-width: 768px) {
            .container {
                width: 100%;
                padding: 10px;
            }

            /* Image Box Styles */
            .image-box {
                width: 90%; /* Ensure image box takes full width on small screens */
                max-width: 100%; /* Remove maximum width restriction */
                margin: 10px 0; /* Add space between boxes */
            }

            /* Title Style */
            h2 {
                font-size: 24px; /* Adjust title font size for mobile */
            }
        }

        /* For very small screens like phones in portrait mode (max-width: 480px) */
        @media (max-width: 480px) {
            h2 {
                font-size: 20px; /* Smaller title font size */
            }

            .name {
                font-size: 14px; /* Smaller name text for small screens */
            }

            .votes {
                font-size: 12px; /* Smaller vote count text */
            }

            .vote-button {
                padding: 8px 16px; /* Adjust button size */
            }
        }
    </style>
</head>
<body>

    <div class="container">
        <h2>Vote for your favorite WCW</h2>

        <?php
        // Display message if there is one in the URL
        if (isset($_GET['success'])) {
            echo "<div class='message success'>" . htmlspecialchars($_GET['success']) . "</div>";
        }
        if (isset($_GET['error'])) {
            echo "<div class='message error'>" . htmlspecialchars($_GET['error']) . "</div>";
        }

        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                // Check if the user has voted
                $disabled = isset($_SESSION['voted']) && $_SESSION['voted'] == true ? 'disabled' : '';

                echo "<div class='image-box'>
                    <img src='" . $row['image_path'] . "' alt='" . $row['name'] . "' class='wcw-image' />
                    <p class='name'>" . $row['name'] . "</p>
                    <p class='votes'>Votes: " . $row['votes'] . "/ 500</p>";
                
                // Only show the vote button if the user hasn't voted
                if ($disabled) {
                    echo "<p>You have already voted!</p>";
                } else {
                    echo "<a href='vote_action.php?id=" . $row['id'] . "' class='vote-button'>Vote</a>";
                }

                echo "</div>";
            }
        } else {
            echo "<p>No approved images to vote for.</p>";
        }
        ?>
    </div>

</body>
</html>
