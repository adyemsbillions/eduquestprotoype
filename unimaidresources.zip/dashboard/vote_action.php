<?php
session_start();
include 'db_connection.php';

// Get image ID from the query string
$image_id = $_GET['id'];

// Check if the user has already voted (check session variable)
if (isset($_SESSION['voted']) && $_SESSION['voted'] == true) {
    // Redirect or show a message if the user has already voted
    header('Location: index.php?error=You have already voted!');
    exit;
}

// Proceed with voting (increment votes for the selected image)
$sql = "UPDATE wcw_images SET votes = votes + 1 WHERE id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $image_id);
$stmt->execute();

// Set session variable to indicate the user has voted
$_SESSION['voted'] = true;

// Redirect back to the main page with a success message
header('Location: index.php?success=Your vote has been counted!');
exit;
?>
